import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '1mb' }));

interface CandidatePlaceInput {
  placeId: string;
  displayName: string;
  formattedAddress: string;
  primaryTypeLabel?: string;
  types?: string[];
  rating?: number;
  userRatingCount?: number;
  priceLevel?: string;
}

interface VisitedReviewInput {
  placeName: string;
  locality: string;
  city: string;
  country: string;
  primaryTypeLabel: string;
  overallRating: number;
  tasteTags: string[];
  favoriteDish?: string;
  wouldReturn: 'yes' | 'maybe' | 'no';
}

app.get('/api/config', (_req, res) => {
  const mapsApiKey =
    process.env.VITE_GOOGLE_MAPS_API_KEY ||
    process.env.GOOGLE_MAPS_API_KEY ||
    '';
  res.json({ mapsApiKey });
});

app.post('/api/recommendations', async (req, res) => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    res.status(503).json({
      error: 'GEMINI_API_KEY is not configured in environment secrets.',
    });
    return;
  }

  const { city, country, tasteLikings, visitedReviews, candidatePlaces } =
    req.body as {
      city?: string;
      country?: string;
      tasteLikings?: string[];
      visitedReviews?: VisitedReviewInput[];
      candidatePlaces?: CandidatePlaceInput[];
    };

  if (!Array.isArray(candidatePlaces) || candidatePlaces.length === 0) {
    res.status(400).json({
      error: 'No candidate places from Google Places search were provided.',
    });
    return;
  }

  const destinationLabel =
    city && country ? `${city}, ${country}` : city || country || 'this city';

  const sanitizedCandidates = candidatePlaces.slice(0, 18).map((p) => ({
    placeId: p.placeId,
    name: p.displayName,
    address: p.formattedAddress,
    category: p.primaryTypeLabel || 'Food & Dining',
    types: (p.types || []).slice(0, 5),
    googleRating: p.rating ?? null,
    reviewCount: p.userRatingCount ?? null,
    priceLevel: p.priceLevel ?? null,
  }));

  const validIds = new Set(sanitizedCandidates.map((c) => c.placeId));

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const promptPayload = {
      targetCity: destinationLabel,
      userLikings:
        tasteLikings && tasteLikings.length > 0
          ? tasteLikings
          : ['Great local dining', 'Coffee & Brunch', 'Memorable flavours'],
      pastVisitedPlaces: (visitedReviews || []).slice(0, 12).map((v) => ({
        name: v.placeName,
        locality: v.locality,
        city: v.city,
        country: v.country,
        category: v.primaryTypeLabel,
        ratingGiven: v.overallRating,
        likedTags: v.tasteTags,
        favoriteDish: v.favoriteDish || '',
        wouldReturn: v.wouldReturn,
      })),
      candidatePlacesFromGoogleMaps: sanitizedCandidates,
    };

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Rank the best 6 unvisited food spots in ${destinationLabel} from candidatePlacesFromGoogleMaps for this diner.
User Taste Data & Candidate Places:
${JSON.stringify(promptPayload)}`,
      config: {
        systemInstruction:
          `You are a knowledgeable global dining curator helping a diner explore ${destinationLabel}. Select up to 6 places STRICTLY from candidatePlacesFromGoogleMaps using their exact placeId values. Never invent new restaurants, addresses, or placeIds. Base matchScore (65-99) and concise 1-2 sentence matchReason directly on the userLikings and pastVisitedPlaces patterns (e.g. cuisines, price comfort, vibes, high-rated tags). Provide a realistic suggestedOrder style note for what to look out for based on the category and local cuisine without fabricating specific secret menu items.`,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              placeId: {
                type: Type.STRING,
                description: 'Exact placeId from candidatePlacesFromGoogleMaps.',
              },
              matchScore: {
                type: Type.INTEGER,
                description: 'Match percentage from 65 to 99.',
              },
              matchReason: {
                type: Type.STRING,
                description:
                  'Concise 1-2 sentence explanation of why this place fits the user likings and rating history.',
              },
              suggestedOrder: {
                type: Type.STRING,
                description: 'Short 3-6 word style cue of what to order or try there.',
              },
            },
            required: ['placeId', 'matchScore', 'matchReason', 'suggestedOrder'],
          },
        },
      },
    });

    const rawText = (response.text ?? '[]').trim();
    const parsed = JSON.parse(rawText) as Array<{
      placeId: string;
      matchScore: number;
      matchReason: string;
      suggestedOrder: string;
    }>;

    const filtered = (Array.isArray(parsed) ? parsed : [])
      .filter(
        (item) =>
          item && typeof item.placeId === 'string' && validIds.has(item.placeId)
      )
      .slice(0, 6);

    res.json({ recommendations: filtered });
  } catch (err) {
    console.error('Gemini recommendation error:', err);
    const message =
      err instanceof Error
        ? err.message
        : 'Failed to generate taste recommendations.';
    res.status(502).json({ error: message });
  }
});

async function startServer() {
  const PORT = Number(process.env.PORT) || 3000;
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Plate & Pin server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
