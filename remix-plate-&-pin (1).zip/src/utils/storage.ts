import type { SelectedDestination, VisitedReview } from '../types/food';

const REVIEWS_KEY = 'platepin_world_reviews_v1';
const LEGACY_REVIEWS_KEY = 'platepin_sydney_reviews_v1';
const LIKINGS_KEY = 'platepin_world_likings_v1';
const LEGACY_LIKINGS_KEY = 'platepin_sydney_likings_v1';
const PROFILE_KEY = 'platepin_world_profile_v1';
const LEGACY_PROFILE_KEY = 'platepin_sydney_profile_v1';
const DESTINATION_KEY = 'platepin_active_destination_v1';

export interface DinerProfile {
  name: string;
  handle: string;
  homeCity: string;
  homeCountry: string;
  bio: string;
}

const DEFAULT_PROFILE: DinerProfile = {
  name: 'Alex Mercer',
  handle: '@alex.tastes',
  homeCity: '',
  homeCountry: '',
  bio: 'Collecting espresso bars, late-night street eats, and memorable plates city by city.',
};

const DEFAULT_LIKINGS: string[] = [
  'coffee-brunch',
  'ramen-japanese',
  'wine-bistro',
];

function normalizeReview(raw: Record<string, unknown>): VisitedReview {
  return {
    placeId: String(raw.placeId ?? ''),
    placeName: String(raw.placeName ?? ''),
    formattedAddress: String(raw.formattedAddress ?? ''),
    locality: String(raw.locality ?? raw.suburb ?? 'Local'),
    city: String(raw.city ?? 'Sydney'),
    country: String(raw.country ?? 'Australia'),
    countryCode: String(raw.countryCode ?? 'AU'),
    location: (raw.location as { lat: number; lng: number }) ?? { lat: 0, lng: 0 },
    primaryTypeLabel: String(raw.primaryTypeLabel ?? 'Food Spot'),
    googleMapsURI: raw.googleMapsURI ? String(raw.googleMapsURI) : undefined,
    photoUri: raw.photoUri ? String(raw.photoUri) : undefined,
    photoAttributions: Array.isArray(raw.photoAttributions)
      ? (raw.photoAttributions as VisitedReview['photoAttributions'])
      : undefined,
    overallRating: Number(raw.overallRating ?? 4),
    foodRating: Number(raw.foodRating ?? 4),
    vibeRating: Number(raw.vibeRating ?? 4),
    valueRating: Number(raw.valueRating ?? 4),
    wouldReturn: (raw.wouldReturn as VisitedReview['wouldReturn']) ?? 'yes',
    favoriteDish: String(raw.favoriteDish ?? ''),
    reviewText: String(raw.reviewText ?? ''),
    tasteTags: Array.isArray(raw.tasteTags) ? (raw.tasteTags as string[]) : [],
    visitedAt: String(raw.visitedAt ?? new Date().toISOString().slice(0, 10)),
  };
}

export function loadVisitedReviews(): VisitedReview[] {
  try {
    const raw =
      localStorage.getItem(REVIEWS_KEY) || localStorage.getItem(LEGACY_REVIEWS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed)
      ? parsed.map((item) => normalizeReview(item as Record<string, unknown>))
      : [];
  } catch {
    return [];
  }
}

export function saveVisitedReviews(reviews: VisitedReview[]): void {
  try {
    localStorage.setItem(REVIEWS_KEY, JSON.stringify(reviews));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadTasteLikings(): string[] {
  try {
    const raw =
      localStorage.getItem(LIKINGS_KEY) || localStorage.getItem(LEGACY_LIKINGS_KEY);
    if (!raw) return DEFAULT_LIKINGS;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : DEFAULT_LIKINGS;
  } catch {
    return DEFAULT_LIKINGS;
  }
}

export function saveTasteLikings(likings: string[]): void {
  try {
    localStorage.setItem(LIKINGS_KEY, JSON.stringify(likings));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadDinerProfile(): DinerProfile {
  try {
    const raw =
      localStorage.getItem(PROFILE_KEY) || localStorage.getItem(LEGACY_PROFILE_KEY);
    if (!raw) return DEFAULT_PROFILE;
    const parsed = JSON.parse(raw) as Record<string, unknown>;
    return {
      ...DEFAULT_PROFILE,
      name: typeof parsed.name === 'string' ? parsed.name : DEFAULT_PROFILE.name,
      handle: typeof parsed.handle === 'string' ? parsed.handle : DEFAULT_PROFILE.handle,
      homeCity:
        typeof parsed.homeCity === 'string'
          ? parsed.homeCity
          : typeof parsed.homeSuburb === 'string'
          ? parsed.homeSuburb
          : '',
      homeCountry:
        typeof parsed.homeCountry === 'string' ? parsed.homeCountry : '',
      bio: typeof parsed.bio === 'string' ? parsed.bio : DEFAULT_PROFILE.bio,
    };
  } catch {
    return DEFAULT_PROFILE;
  }
}

export function saveDinerProfile(profile: DinerProfile): void {
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadActiveDestination(): SelectedDestination | null {
  try {
    const raw = localStorage.getItem(DESTINATION_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as SelectedDestination;
    if (
      parsed &&
      parsed.cityName &&
      parsed.countryCode &&
      parsed.center &&
      typeof parsed.center.lat === 'number' &&
      typeof parsed.center.lng === 'number'
    ) {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}

export function saveActiveDestination(destination: SelectedDestination): void {
  try {
    localStorage.setItem(DESTINATION_KEY, JSON.stringify(destination));
  } catch {
    // Ignore storage quota errors
  }
}
