import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { APIProvider } from '@vis.gl/react-google-maps';
import {
  CheckSquare,
  Compass,
  Map as MapIcon,
  Plus,
  User,
} from 'lucide-react';
import { DestinationSelector } from './components/DestinationSelector';
import { InteractiveCheckBoard } from './components/InteractiveCheckBoard';
import { ProfileView } from './components/ProfileView';
import { QuickLogModal } from './components/QuickLogModal';
import { RatingModal } from './components/RatingModal';
import { RecommendationsView } from './components/RecommendationsView';
import { WorldMapView } from './components/WorldMapView';
import type {
  AppTab,
  FoodPlace,
  LatLngPoint,
  SelectedDestination,
  TasteRecommendation,
  VisitedReview,
} from './types/food';
import {
  DinerProfile,
  loadActiveDestination,
  loadDinerProfile,
  loadTasteLikings,
  loadVisitedReviews,
  saveActiveDestination,
  saveDinerProfile,
  saveTasteLikings,
  saveVisitedReviews,
} from './utils/storage';

interface WorkspaceProps {
  quotaExceeded: boolean;
}

const Workspace: React.FC<WorkspaceProps> = ({ quotaExceeded }) => {
  const [activeDestination, setActiveDestination] =
    useState<SelectedDestination | null>(() => loadActiveDestination());
  const [showDestinationModal, setShowDestinationModal] = useState(false);

  const [activeTab, setActiveTab] = useState<AppTab>('map');
  const [discoveredPlaces, setDiscoveredPlaces] = useState<FoodPlace[]>([]);
  const [visitedReviews, setVisitedReviews] = useState<VisitedReview[]>(() =>
    loadVisitedReviews()
  );
  const [tasteLikings, setTasteLikings] = useState<string[]>(() =>
    loadTasteLikings()
  );
  const [profile, setProfile] = useState<DinerProfile>(() =>
    loadDinerProfile()
  );
  const [recommendations, setRecommendations] = useState<
    TasteRecommendation[]
  >([]);

  const [selectedPlace, setSelectedPlace] = useState<FoodPlace | null>(null);
  const [placeToRate, setPlaceToRate] = useState<FoodPlace | null>(null);
  const [showQuickLog, setShowQuickLog] = useState(false);
  const [focusRequest, setFocusRequest] = useState<{
    center: LatLngPoint;
    zoom?: number;
    timestamp: number;
  } | null>(null);

  const visitedByPlaceId = useMemo(() => {
    const map: Record<string, VisitedReview> = {};
    visitedReviews.forEach((rev) => {
      map[rev.placeId] = rev;
    });
    return map;
  }, [visitedReviews]);

  const recommendationsByPlaceId = useMemo(() => {
    const map: Record<string, TasteRecommendation> = {};
    recommendations.forEach((rec) => {
      map[rec.placeId] = rec;
    });
    return map;
  }, [recommendations]);

  const visitedCities = useMemo<SelectedDestination[]>(() => {
    const map: Record<string, SelectedDestination> = {};
    visitedReviews.forEach((rev) => {
      const key = `${rev.city.toLowerCase()}|${rev.countryCode.toLowerCase()}`;
      if (!map[key]) {
        map[key] = {
          id: `${rev.city}-${rev.countryCode}`,
          cityName: rev.city,
          countryName: rev.country,
          countryCode: rev.countryCode,
          formattedAddress: `${rev.city}, ${rev.country}`,
          center: rev.location,
        };
      }
    });
    return Object.values(map);
  }, [visitedReviews]);

  const handleSelectDestination = useCallback(
    (dest: SelectedDestination) => {
      setActiveDestination(dest);
      saveActiveDestination(dest);
      setShowDestinationModal(false);
      setSelectedPlace(null);
      setRecommendations([]);
      setDiscoveredPlaces([]);
      setFocusRequest({
        center: dest.center,
        zoom: 13,
        timestamp: Date.now(),
      });
    },
    []
  );

  const handlePlacesDiscovered = useCallback(
    (incoming: FoodPlace[], replaceCityFeed = false) => {
      setDiscoveredPlaces((prev) => {
        const merged: Record<string, FoodPlace> = {};
        if (!replaceCityFeed) {
          prev.forEach((p) => {
            merged[p.id] = p;
          });
        }
        incoming.forEach((p) => {
          merged[p.id] = { ...merged[p.id], ...p };
        });
        return Object.values(merged);
      });
    },
    []
  );

  const handleSaveReview = useCallback(
    (review: VisitedReview) => {
      setVisitedReviews((prev) => {
        const filtered = prev.filter((r) => r.placeId !== review.placeId);
        const next = [review, ...filtered];
        saveVisitedReviews(next);
        return next;
      });

      if (placeToRate) {
        handlePlacesDiscovered([placeToRate]);
        setSelectedPlace(placeToRate);
      }

      setRecommendations((prev) =>
        prev.filter((r) => r.placeId !== review.placeId)
      );
      setPlaceToRate(null);
    },
    [placeToRate, handlePlacesDiscovered]
  );

  const handleRemoveVisit = useCallback((placeId: string) => {
    setVisitedReviews((prev) => {
      const next = prev.filter((r) => r.placeId !== placeId);
      saveVisitedReviews(next);
      return next;
    });
  }, []);

  const handleToggleLiking = useCallback((likingId: string) => {
    setTasteLikings((prev) => {
      const next = prev.includes(likingId)
        ? prev.filter((id) => id !== likingId)
        : [...prev, likingId];
      saveTasteLikings(next);
      return next;
    });
  }, []);

  const handleUpdateProfile = useCallback((nextProfile: DinerProfile) => {
    setProfile(nextProfile);
    saveDinerProfile(nextProfile);
  }, []);

  const handleJumpToPlaceOnMap = useCallback(
    (place: FoodPlace) => {
      handlePlacesDiscovered([place]);
      setSelectedPlace(place);
      setFocusRequest({
        center: place.location,
        zoom: 16,
        timestamp: Date.now(),
      });
      setActiveTab('map');
    },
    [handlePlacesDiscovered]
  );

  const handleJumpToReviewOnMap = useCallback(
    (review: VisitedReview) => {
      const asPlace: FoodPlace =
        discoveredPlaces.find((p) => p.id === review.placeId) ?? {
          id: review.placeId,
          displayName: review.placeName,
          formattedAddress: review.formattedAddress,
          locality: review.locality,
          city: review.city,
          country: review.country,
          countryCode: review.countryCode,
          location: review.location,
          primaryType: 'restaurant',
          primaryTypeLabel: review.primaryTypeLabel,
          types: [],
          photoUri: review.photoUri,
          photoAttributions: review.photoAttributions,
          googleMapsURI: review.googleMapsURI,
        };
      handleJumpToPlaceOnMap(asPlace);
    },
    [discoveredPlaces, handleJumpToPlaceOnMap]
  );

  const handleJumpToCityOnMap = useCallback(
    (cityDest: SelectedDestination) => {
      handleSelectDestination(cityDest);
      setActiveTab('map');
    },
    [handleSelectDestination]
  );

  const handleEditReviewFromBoard = useCallback(
    (review: VisitedReview) => {
      const asPlace: FoodPlace =
        discoveredPlaces.find((p) => p.id === review.placeId) ?? {
          id: review.placeId,
          displayName: review.placeName,
          formattedAddress: review.formattedAddress,
          locality: review.locality,
          city: review.city,
          country: review.country,
          countryCode: review.countryCode,
          location: review.location,
          primaryType: 'restaurant',
          primaryTypeLabel: review.primaryTypeLabel,
          types: [],
          photoUri: review.photoUri,
          photoAttributions: review.photoAttributions,
          googleMapsURI: review.googleMapsURI,
        };
      setPlaceToRate(asPlace);
    },
    [discoveredPlaces]
  );

  const quotaBanner = quotaExceeded ? (
    <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
      <span>
        Google Maps Platform quota reached. If you are the app owner, visit{' '}
        <a
          href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
          target="_blank"
          rel="noopener noreferrer"
          className="underline font-semibold text-amber-950 hover:text-amber-800"
        >
          maps developer site
        </a>{' '}
        for instructions to update your account.
      </span>
    </div>
  ) : null;

  if (!activeDestination) {
    return (
      <div className="min-h-screen flex flex-col bg-[#F6F4EF] text-[#141311]">
        {quotaBanner}
        <DestinationSelector
          currentDestination={null}
          onSelectDestination={handleSelectDestination}
          visitedCities={visitedCities}
        />
      </div>
    );
  }

  const navItems: Array<{
    id: AppTab;
    label: string;
    mobileLabel: string;
    icon: React.ReactNode;
  }> = [
    {
      id: 'map',
      label: 'Food Map',
      mobileLabel: 'Map',
      icon: <MapIcon className="w-5 h-5" />,
    },
    {
      id: 'for-you',
      label: 'For You',
      mobileLabel: 'For You',
      icon: <Compass className="w-5 h-5" />,
    },
    {
      id: 'checkboard',
      label: 'Check Board',
      mobileLabel: 'Board',
      icon: <CheckSquare className="w-5 h-5" />,
    },
    {
      id: 'profile',
      label: 'Profile',
      mobileLabel: 'Profile',
      icon: <User className="w-5 h-5" />,
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F4EF] text-[#141311]">
      {quotaBanner}

      {/* Top Bar Contract (3 zones separated by gap-8) */}
      <header className="sticky top-0 z-30 h-[54px] md:h-16 bg-white/95 backdrop-blur-md border-b border-[#E3DFD6] px-4 sm:px-6 flex items-center justify-between gap-8">
        <button
          type="button"
          onClick={() => setActiveTab('map')}
          className="text-lg sm:text-xl font-bold tracking-tight text-[#141311] font-display whitespace-nowrap shrink-0 text-left"
        >
          Plate &amp; Pin
        </button>

        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#52504A]">
          {navItems.map((item) => {
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`py-1.5 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'text-[#141311] font-semibold border-[#E84231]'
                    : 'border-transparent hover:text-[#141311]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={() => setShowQuickLog(true)}
            className="min-h-[40px] px-3.5 sm:px-4 rounded-xl bg-[#E84231] hover:bg-[#D13322] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Log a Visit</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main
        className={`flex-1 w-full px-3 sm:px-6 py-4 pb-24 md:pb-6 ${
          activeTab === 'map'
            ? 'lg:h-[calc(100vh-64px)] lg:overflow-hidden'
            : ''
        }`}
      >
        {activeTab === 'map' && (
          <WorldMapView
            destination={activeDestination}
            onOpenDestinationPicker={() => setShowDestinationModal(true)}
            discoveredPlaces={discoveredPlaces}
            onPlacesDiscovered={handlePlacesDiscovered}
            visitedByPlaceId={visitedByPlaceId}
            recommendationsByPlaceId={recommendationsByPlaceId}
            selectedPlace={selectedPlace}
            onSelectPlace={setSelectedPlace}
            onOpenRate={(place) => setPlaceToRate(place)}
            onRemoveVisit={handleRemoveVisit}
            focusRequest={focusRequest}
          />
        )}

        {activeTab === 'for-you' && (
          <RecommendationsView
            destination={activeDestination}
            onOpenDestinationPicker={() => setShowDestinationModal(true)}
            tasteLikings={tasteLikings}
            onToggleLiking={handleToggleLiking}
            visitedReviews={visitedReviews}
            discoveredPlaces={discoveredPlaces}
            onPlacesDiscovered={handlePlacesDiscovered}
            recommendations={recommendations}
            onRecommendationsLoaded={setRecommendations}
            onSelectAndFocusMap={handleJumpToPlaceOnMap}
            onOpenRate={(place) => setPlaceToRate(place)}
          />
        )}

        {activeTab === 'checkboard' && (
          <div className="max-w-6xl mx-auto pb-6">
            <InteractiveCheckBoard
              destination={activeDestination}
              visitedReviews={visitedReviews}
              onJumpToPlaceOnMap={handleJumpToReviewOnMap}
              onJumpToCityOnMap={handleJumpToCityOnMap}
              onOpenDestinationPicker={() => setShowDestinationModal(true)}
              onEditReview={handleEditReviewFromBoard}
              onOpenQuickLog={() => setShowQuickLog(true)}
            />
          </div>
        )}

        {activeTab === 'profile' && (
          <ProfileView
            destination={activeDestination}
            onOpenDestinationPicker={() => setShowDestinationModal(true)}
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            tasteLikings={tasteLikings}
            onToggleLiking={handleToggleLiking}
            visitedReviews={visitedReviews}
            onJumpToPlaceOnMap={handleJumpToReviewOnMap}
            onJumpToCityOnMap={handleJumpToCityOnMap}
            onEditReview={handleEditReviewFromBoard}
            onOpenQuickLog={() => setShowQuickLog(true)}
          />
        )}
      </main>

      {/* Mobile Bottom Tab Bar */}
      <nav
        aria-label="Primary mobile navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#E3DFD6] grid grid-cols-4 items-center h-16 pb-safe"
      >
        {navItems.map((item) => {
          const active = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`min-h-[44px] flex flex-col items-center justify-center gap-0.5 transition-colors ${
                active ? 'text-[#E84231]' : 'text-[#6E6C66]'
              }`}
            >
              {item.icon}
              <span className="text-[10px] font-semibold tracking-tight whitespace-nowrap">
                {item.mobileLabel}
              </span>
            </button>
          );
        })}
      </nav>

      {showDestinationModal && (
        <DestinationSelector
          currentDestination={activeDestination}
          onSelectDestination={handleSelectDestination}
          onClose={() => setShowDestinationModal(false)}
          visitedCities={visitedCities}
        />
      )}

      {showQuickLog && (
        <QuickLogModal
          destination={activeDestination}
          onClose={() => setShowQuickLog(false)}
          onOpenDestinationPicker={() => {
            setShowQuickLog(false);
            setShowDestinationModal(true);
          }}
          onPlaceChosenForRating={(place) => {
            handlePlacesDiscovered([place]);
            setShowQuickLog(false);
            setPlaceToRate(place);
          }}
        />
      )}

      {placeToRate && (
        <RatingModal
          place={placeToRate}
          existingReview={visitedByPlaceId[placeToRate.id]}
          onClose={() => setPlaceToRate(null)}
          onSave={handleSaveReview}
        />
      )}
    </div>
  );
};

export default function App() {
  const [mapsApiKey, setMapsApiKey] = useState<string>(
    () => import.meta.env.VITE_GOOGLE_MAPS_API_KEY || ''
  );
  const [configLoaded, setConfigLoaded] = useState<boolean>(() =>
    Boolean(import.meta.env.VITE_GOOGLE_MAPS_API_KEY)
  );
  const [quotaExceeded, setQuotaExceeded] = useState(false);

  useEffect(() => {
    const handleQuota = () => setQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', handleQuota);
    return () => window.removeEventListener('gmp-quota-exceeded', handleQuota);
  }, []);

  useEffect(() => {
    if (mapsApiKey) return;
    let cancelled = false;
    fetch('/api/config')
      .then((res) => res.json())
      .then((data: { mapsApiKey?: string }) => {
        if (!cancelled) {
          setMapsApiKey(data.mapsApiKey || '');
          setConfigLoaded(true);
        }
      })
      .catch(() => {
        if (!cancelled) setConfigLoaded(true);
      });
    return () => {
      cancelled = true;
    };
  }, [mapsApiKey]);

  if (!configLoaded) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F6F4EF] text-[#52504A] text-sm">
        Loading worldwide dining map...
      </div>
    );
  }

  if (!mapsApiKey) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F6F4EF] p-6">
        <div className="max-w-md bg-white border border-[#E3DFD6] rounded-2xl p-6 text-center space-y-2">
          <h1 className="text-xl font-bold text-[#141311]">
            Google Maps API key required
          </h1>
          <p className="text-sm text-[#52504A]">
            Enable Google Maps Platform in AI Studio settings or configure VITE_GOOGLE_MAPS_API_KEY to load the interactive worldwide food map.
          </p>
        </div>
      </div>
    );
  }

  return (
    <APIProvider
      apiKey={mapsApiKey}
      libraries={['places', 'marker']}
      language="en"
    >
      <Workspace quotaExceeded={quotaExceeded} />
    </APIProvider>
  );
}
