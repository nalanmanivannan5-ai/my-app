import { useCallback, useEffect, useRef, useState } from 'react';
import { useMapsLibrary } from '@vis.gl/react-google-maps';
import type { LatLngPoint } from '../types/food';

export interface UseAutocompleteOptions {
  mode?: 'food' | 'cities';
  countryCode?: string;
  center?: LatLngPoint;
}

export interface UseAutocompleteSuggestionsReturn {
  suggestions: google.maps.places.AutocompleteSuggestion[];
  isLoading: boolean;
  resetSession: () => void;
}

export function useAutocompleteSuggestions(
  inputString: string,
  options: UseAutocompleteOptions = {}
): UseAutocompleteSuggestionsReturn {
  const { mode = 'food', countryCode, center } = options;
  const placesLib = useMapsLibrary('places');
  const sessionTokenRef =
    useRef<google.maps.places.AutocompleteSessionToken | null>(null);
  const [suggestions, setSuggestions] = useState<
    google.maps.places.AutocompleteSuggestion[]
  >([]);
  const [isLoading, setIsLoading] = useState(false);

  const resetSession = useCallback(() => {
    sessionTokenRef.current = null;
    setSuggestions([]);
  }, []);

  useEffect(() => {
    if (!placesLib) return;

    const trimmed = inputString.trim();
    if (trimmed.length < 2) {
      setSuggestions([]);
      setIsLoading(false);
      return;
    }

    if (mode === 'cities' && !countryCode) {
      setSuggestions([]);
      setIsLoading(false);
      return;
    }

    const { AutocompleteSessionToken, AutocompleteSuggestion } = placesLib;

    if (!sessionTokenRef.current) {
      sessionTokenRef.current = new AutocompleteSessionToken();
    }

    let cancelled = false;
    const timer = window.setTimeout(async () => {
      setIsLoading(true);
      try {
        const regionLower = countryCode ? countryCode.toLowerCase() : undefined;

        const request: google.maps.places.AutocompleteRequest =
          mode === 'cities'
            ? {
                input: trimmed,
                sessionToken: sessionTokenRef.current ?? undefined,
                includedPrimaryTypes: ['(cities)'],
                includedRegionCodes: regionLower ? [regionLower] : undefined,
                language: 'en',
                region: regionLower,
              }
            : {
                input: trimmed,
                sessionToken: sessionTokenRef.current ?? undefined,
                includedPrimaryTypes: [
                  'restaurant',
                  'cafe',
                  'bakery',
                  'bar',
                  'meal_takeaway',
                ],
                includedRegionCodes: regionLower ? [regionLower] : undefined,
                locationBias: center
                  ? {
                      center,
                      radius: 25000,
                    }
                  : undefined,
                language: 'en',
                region: regionLower,
              };

        const res =
          await AutocompleteSuggestion.fetchAutocompleteSuggestions(request);
        if (!cancelled) {
          setSuggestions(res.suggestions ?? []);
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        if (
          msg.includes('RESOURCE_EXHAUSTED') ||
          msg.includes('OVER_QUERY_LIMIT') ||
          msg.includes('429')
        ) {
          window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
        }
        if (!cancelled) {
          setSuggestions([]);
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }, 220);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [
    placesLib,
    inputString,
    mode,
    countryCode,
    center?.lat,
    center?.lng,
  ]);

  return {
    suggestions,
    isLoading,
    resetSession,
  };
}
