import type { VisitedReview } from '../types/food';

export interface TastePreferenceOption {
  id: string;
  label: string;
  searchHint: string;
}

export interface MapCategoryFilter {
  id: string;
  label: string;
  includedPrimaryTypes?: string[];
  textQuery?: string;
}

export const MAP_CATEGORY_FILTERS: MapCategoryFilter[] = [
  {
    id: 'all-dining',
    label: 'All Dining',
    includedPrimaryTypes: ['restaurant', 'cafe', 'bakery'],
  },
  {
    id: 'restaurants',
    label: 'Restaurants',
    includedPrimaryTypes: ['restaurant'],
  },
  {
    id: 'cafes',
    label: 'Cafes & Brunch',
    includedPrimaryTypes: ['cafe', 'coffee_shop'],
  },
  {
    id: 'bakeries',
    label: 'Bakeries & Pastry',
    includedPrimaryTypes: ['bakery'],
  },
  {
    id: 'bars',
    label: 'Bars & Wine',
    includedPrimaryTypes: ['bar', 'wine_bar'],
  },
  {
    id: 'street-food',
    label: 'Casual & Street Food',
    textQuery: 'street food casual local eats',
  },
  {
    id: 'desserts',
    label: 'Dessert & Gelato',
    includedPrimaryTypes: ['ice_cream_shop', 'dessert_shop', 'bakery'],
  },
];

export const TASTE_LIKING_OPTIONS: TastePreferenceOption[] = [
  { id: 'coffee-brunch', label: 'Specialty Coffee & Brunch', searchHint: 'specialty coffee brunch cafe' },
  { id: 'ramen-japanese', label: 'Ramen & Izakaya', searchHint: 'ramen japanese izakaya restaurant' },
  { id: 'woodfired-pasta', label: 'Wood-Fired & Pasta', searchHint: 'italian pasta wood fired pizza restaurant' },
  { id: 'coastal-seafood', label: 'Seafood & Raw Bar', searchHint: 'fresh seafood oyster restaurant' },
  { id: 'spicy-asian', label: 'Spicy & Regional Asian', searchHint: 'authentic thai spicy regional asian restaurant' },
  { id: 'dumplings-noodles', label: 'Dumplings & Noodles', searchHint: 'dumplings handmade noodles restaurant' },
  { id: 'wine-bistro', label: 'Wine Bars & Bistro Plates', searchHint: 'wine bar bistro small plates' },
  { id: 'artisan-bakery', label: 'Artisan Bakery & Pastry', searchHint: 'artisan bakery croissant pastry' },
  { id: 'street-casual', label: 'Street Food & Casual Eats', searchHint: 'street food market casual local eats' },
  { id: 'plant-forward', label: 'Plant-Forward & Vegetarian', searchHint: 'vegetarian plant based restaurant' },
  { id: 'burgers-late', label: 'Burgers & Late Night', searchHint: 'smash burger late night diner' },
  { id: 'gelato-dessert', label: 'Gelato & Dessert', searchHint: 'artisan gelato dessert bar' },
];

export const REVIEW_TASTE_TAGS = [
  'Spicy',
  'Umami',
  'Specialty Coffee',
  'Wood-Fired',
  'Fresh Seafood',
  'Handmade Pasta',
  'Crispy & Fried',
  'Sweet & Pastry',
  'Late Night',
  'Great Value',
  'Date Night',
  'Outdoor Seating',
];

export interface CheckboardMilestone {
  id: string;
  title: string;
  requirement: string;
  isUnlocked: (reviews: VisitedReview[]) => boolean;
  progressText: (reviews: VisitedReview[]) => string;
}

export const CHECKBOARD_MILESTONES: CheckboardMilestone[] = [
  {
    id: 'first-dot',
    title: 'First World Pin',
    requirement: 'Check in and rate your first food spot anywhere',
    isUnlocked: (reviews) => reviews.length >= 1,
    progressText: (reviews) => `${Math.min(reviews.length, 1)} / 1`,
  },
  {
    id: 'three-neighborhoods',
    title: 'Neighborhood Hopper',
    requirement: 'Drop visited dots across 3 different neighborhoods',
    isUnlocked: (reviews) =>
      new Set(reviews.map((r) => r.locality.toLowerCase()).filter(Boolean)).size >= 3,
    progressText: (reviews) =>
      `${Math.min(new Set(reviews.map((r) => r.locality.toLowerCase()).filter(Boolean)).size, 3)} / 3`,
  },
  {
    id: 'two-cities',
    title: 'City Hopper',
    requirement: 'Stamp dining spots in 2 different cities',
    isUnlocked: (reviews) =>
      new Set(reviews.map((r) => `${r.city.toLowerCase()}|${r.countryCode.toLowerCase()}`)).size >= 2,
    progressText: (reviews) =>
      `${Math.min(new Set(reviews.map((r) => `${r.city.toLowerCase()}|${r.countryCode.toLowerCase()}`)).size, 2)} / 2`,
  },
  {
    id: 'two-countries',
    title: 'Passport Stamper',
    requirement: 'Rate food spots across 2 different countries',
    isUnlocked: (reviews) =>
      new Set(reviews.map((r) => r.countryCode.toLowerCase()).filter(Boolean)).size >= 2,
    progressText: (reviews) =>
      `${Math.min(new Set(reviews.map((r) => r.countryCode.toLowerCase()).filter(Boolean)).size, 2)} / 2`,
  },
  {
    id: 'five-star-gem',
    title: 'Five-Star Gem',
    requirement: 'Award a full 5.0 rating to an unforgettable spot',
    isUnlocked: (reviews) => reviews.some((r) => r.overallRating >= 5),
    progressText: (reviews) => (reviews.some((r) => r.overallRating >= 5) ? '1 / 1' : '0 / 1'),
  },
  {
    id: 'cafe-regular',
    title: 'Morning Ritual',
    requirement: 'Rate 2 cafes, bakeries, or brunch spots',
    isUnlocked: (reviews) =>
      reviews.filter((r) =>
        /cafe|coffee|bakery|brunch|pastry/i.test(`${r.primaryTypeLabel} ${r.tasteTags.join(' ')}`)
      ).length >= 2,
    progressText: (reviews) => {
      const count = reviews.filter((r) =>
        /cafe|coffee|bakery|brunch|pastry/i.test(`${r.primaryTypeLabel} ${r.tasteTags.join(' ')}`)
      ).length;
      return `${Math.min(count, 2)} / 2`;
    },
  },
  {
    id: 'five-visits',
    title: 'Seasoned Taster',
    requirement: 'Stamp 5 places on your global check board',
    isUnlocked: (reviews) => reviews.length >= 5,
    progressText: (reviews) => `${Math.min(reviews.length, 5)} / 5`,
  },
  {
    id: 'ten-visits',
    title: 'World Food Atlas',
    requirement: 'Build a map of 10 visited spots worldwide',
    isUnlocked: (reviews) => reviews.length >= 10,
    progressText: (reviews) => `${Math.min(reviews.length, 10)} / 10`,
  },
];
