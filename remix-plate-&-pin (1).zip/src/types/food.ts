export interface LatLngPoint {
  lat: number;
  lng: number;
}

export interface ViewportBounds {
  south: number;
  west: number;
  north: number;
  east: number;
}

export interface CountryOption {
  code: string;
  name: string;
  continent: string;
}

export interface SelectedDestination {
  id: string;
  cityName: string;
  countryName: string;
  countryCode: string;
  formattedAddress: string;
  center: LatLngPoint;
  viewport?: ViewportBounds;
}

export interface PlaceAuthorAttribution {
  displayName?: string | null;
  uri?: string | null;
}

export interface PlaceReviewSnippet {
  rating?: number | null;
  text?: string | null;
  relativePublishTimeDescription?: string | null;
  authorName?: string | null;
}

export interface FoodPlace {
  id: string;
  displayName: string;
  formattedAddress: string;
  locality: string;
  city: string;
  country: string;
  countryCode: string;
  location: LatLngPoint;
  primaryType: string;
  primaryTypeLabel: string;
  types: string[];
  rating?: number;
  userRatingCount?: number;
  priceLevel?: string;
  photoUri?: string;
  photoAttributions?: PlaceAuthorAttribution[];
  googleMapsURI?: string;
  attributions?: Array<{ provider: string; providerURI?: string | null }>;
  editorialSummary?: string;
  websiteURI?: string;
  isOpenNow?: boolean;
  reviews?: PlaceReviewSnippet[];
}

export type ReturnIntent = 'yes' | 'maybe' | 'no';

export interface VisitedReview {
  placeId: string;
  placeName: string;
  formattedAddress: string;
  locality: string;
  city: string;
  country: string;
  countryCode: string;
  location: LatLngPoint;
  primaryTypeLabel: string;
  googleMapsURI?: string;
  photoUri?: string;
  photoAttributions?: PlaceAuthorAttribution[];
  overallRating: number;
  foodRating: number;
  vibeRating: number;
  valueRating: number;
  wouldReturn: ReturnIntent;
  favoriteDish: string;
  reviewText: string;
  tasteTags: string[];
  visitedAt: string;
}

export interface TasteRecommendation {
  placeId: string;
  matchScore: number;
  matchReason: string;
  suggestedOrder: string;
}

export type AppTab = 'map' | 'for-you' | 'checkboard' | 'profile';

export type MapPinFilter = 'all' | 'visited' | 'recommended';
