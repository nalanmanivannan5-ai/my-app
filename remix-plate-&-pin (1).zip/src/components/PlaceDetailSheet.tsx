import React, { useEffect, useState } from 'react';
import { useMapsLibrary } from '@vis.gl/react-google-maps';
import { motion } from 'motion/react';
import {
  CheckCircle2,
  ExternalLink,
  MapPin,
  Pencil,
  Star,
  Trash2,
  Utensils,
  X,
} from 'lucide-react';
import { fetchFoodPlaceDetails } from '../services/placesService';
import type { FoodPlace, TasteRecommendation, VisitedReview } from '../types/food';

interface PlaceDetailSheetProps {
  place: FoodPlace;
  visitedReview?: VisitedReview;
  recommendation?: TasteRecommendation;
  onClose: () => void;
  onOpenRate: (place: FoodPlace) => void;
  onRemoveVisit: (placeId: string) => void;
  onFocusOnMap?: (place: FoodPlace) => void;
}

export const PlaceDetailSheet: React.FC<PlaceDetailSheetProps> = ({
  place,
  visitedReview,
  recommendation,
  onClose,
  onOpenRate,
  onRemoveVisit,
  onFocusOnMap,
}) => {
  const placesLib = useMapsLibrary('places');
  const [detailedPlace, setDetailedPlace] = useState<FoodPlace>(place);
  const [loadingDetails, setLoadingDetails] = useState(false);

  useEffect(() => {
    setDetailedPlace(place);
    if (!placesLib || !place.id) return;

    let cancelled = false;
    setLoadingDetails(true);
    fetchFoodPlaceDetails(placesLib, place.id, {
      city: place.city,
      country: place.country,
      countryCode: place.countryCode,
    })
      .then((enriched) => {
        if (!cancelled && enriched) {
          setDetailedPlace((prev) => ({
            ...prev,
            ...enriched,
            photoUri: enriched.photoUri || prev.photoUri,
            photoAttributions: enriched.photoAttributions || prev.photoAttributions,
          }));
        }
      })
      .catch(() => {
        // Keep base place details if extra fetch fails
      })
      .finally(() => {
        if (!cancelled) setLoadingDetails(false);
      });

    return () => {
      cancelled = true;
    };
  }, [place, placesLib]);

  const activePlace = detailedPlace;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="bg-white border border-[#E3DFD6] rounded-t-3xl lg:rounded-2xl overflow-hidden shadow-xl flex flex-col max-h-[82vh] lg:max-h-full"
    >
      {/* Editorial Photo Header */}
      <div className="relative h-48 sm:h-52 w-full bg-[#1C1B18] shrink-0 overflow-hidden">
        {activePlace.photoUri ? (
          <img
            src={activePlace.photoUri}
            alt={activePlace.displayName}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-[#23211E] to-[#141311] text-[#A8A39A]">
            <Utensils className="w-8 h-8 mb-2 opacity-60" />
            <span className="text-xs font-medium">{activePlace.primaryTypeLabel}</span>
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-black/15" />

        <button
          type="button"
          onClick={onClose}
          aria-label="Close place details"
          className="absolute top-3.5 right-3.5 min-h-[40px] min-w-[40px] flex items-center justify-center rounded-full bg-black/55 backdrop-blur-md text-white hover:bg-black/80 transition-colors border border-white/15"
        >
          <X className="w-4 h-4" />
        </button>

        {visitedReview && (
          <div className="absolute top-3.5 left-3.5 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#0E7C58] text-white text-xs font-semibold shadow-md border border-white/20">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Visited Dot</span>
          </div>
        )}

        <div className="absolute bottom-3.5 left-4 right-4 text-white">
          <h3 className="text-xl sm:text-2xl font-bold leading-tight truncate tracking-tight">
            {activePlace.displayName}
          </h3>
          <div className="flex flex-wrap items-center gap-1.5 text-xs text-white/85 mt-1">
            <span className="font-medium text-white">
              {activePlace.locality || activePlace.city}
            </span>
            <span aria-hidden="true">·</span>
            <span>{activePlace.city}</span>
            <span aria-hidden="true">·</span>
            <span>{activePlace.primaryTypeLabel}</span>
            {activePlace.priceLevel && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-mono">{activePlace.priceLevel}</span>
              </>
            )}
            {activePlace.rating && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums font-semibold text-white">
                  {activePlace.rating.toFixed(1)} Google
                </span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Scrollable Body */}
      <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
        {activePlace.photoAttributions && activePlace.photoAttributions.length > 0 && (
          <p className="text-[11px] text-[#7A766E]">
            Photo by{' '}
            {activePlace.photoAttributions
              .map((a) => a.displayName)
              .filter(Boolean)
              .join(', ') || 'Google Maps contributor'}
          </p>
        )}

        <div className="flex items-start justify-between gap-3 text-sm text-[#45433E]">
          <div className="flex items-start gap-2 min-w-0">
            <MapPin className="w-4 h-4 text-[#7A766E] mt-0.5 shrink-0" />
            <span className="leading-snug">{activePlace.formattedAddress}</span>
          </div>
          {activePlace.googleMapsURI && (
            <a
              href={activePlace.googleMapsURI}
              target="_blank"
              rel="noopener noreferrer"
              className="shrink-0 inline-flex items-center gap-1 text-xs font-semibold text-[#141311] underline underline-offset-4 hover:text-[#E84231] whitespace-nowrap"
            >
              <span>Google Maps</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}
        </div>

        {/* Personalized Match Callout */}
        {recommendation && !visitedReview && (
          <div className="p-4 rounded-2xl bg-[#141311] text-white space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-[#FF7B6B]">
                Picked for your palate
              </span>
              <span className="font-mono tabular-nums font-bold text-white">
                {recommendation.matchScore}% match
              </span>
            </div>
            <p className="text-sm text-white/90 leading-relaxed">
              {recommendation.matchReason}
            </p>
            {recommendation.suggestedOrder && (
              <p className="text-xs text-white/70 pt-0.5">
                Look for: <span className="font-semibold text-white">{recommendation.suggestedOrder}</span>
              </p>
            )}
          </div>
        )}

        {/* Visited Review Card */}
        {visitedReview ? (
          <div className="p-4 rounded-2xl bg-[#F0F7F4] border border-[#C3E0D4] space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="font-mono tabular-nums text-xl font-bold text-[#0E7C58] flex items-center gap-1">
                  <Star className="w-4 h-4 fill-[#0E7C58] text-[#0E7C58]" />
                  {visitedReview.overallRating.toFixed(1)}
                </span>
                <span className="text-xs text-[#45433E] font-mono tabular-nums">
                  {visitedReview.visitedAt}
                </span>
              </div>
              <span className="text-xs font-semibold text-[#0E7C58]">
                {visitedReview.wouldReturn === 'yes'
                  ? 'Would return'
                  : visitedReview.wouldReturn === 'maybe'
                  ? 'Maybe again'
                  : 'One-time visit'}
              </span>
            </div>

            {/* Sub-rating Mini Meters */}
            <div className="grid grid-cols-3 gap-2.5">
              {[
                { label: 'Food', val: visitedReview.foodRating },
                { label: 'Vibe', val: visitedReview.vibeRating },
                { label: 'Value', val: visitedReview.valueRating },
              ].map((m) => (
                <div key={m.label} className="bg-white/80 rounded-xl p-2 border border-[#D7EBE2]">
                  <div className="flex items-center justify-between text-[11px] text-[#45433E]">
                    <span>{m.label}</span>
                    <span className="font-mono tabular-nums font-bold text-[#141311]">
                      {m.val}/5
                    </span>
                  </div>
                  <div className="h-1 bg-[#DCECE5] rounded-full mt-1.5 overflow-hidden">
                    <div
                      className="h-full bg-[#0E7C58] rounded-full"
                      style={{ width: `${(m.val / 5) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            {visitedReview.favoriteDish && (
              <p className="text-sm text-[#141311]">
                <span className="font-semibold">Standout order:</span>{' '}
                {visitedReview.favoriteDish}
              </p>
            )}

            {visitedReview.reviewText && (
              <p className="text-sm text-[#35332F] leading-relaxed">
                “{visitedReview.reviewText}”
              </p>
            )}

            {visitedReview.tasteTags.length > 0 && (
              <p className="text-xs text-[#45433E]">
                {visitedReview.tasteTags.join(' · ')}
              </p>
            )}

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => onOpenRate(activePlace)}
                className="flex-1 min-h-[44px] px-3 rounded-xl bg-white border border-[#C3E0D4] text-xs font-semibold text-[#141311] hover:bg-[#F6F4EF] flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
              >
                <Pencil className="w-3.5 h-3.5" />
                <span>Edit Review</span>
              </button>
              <button
                type="button"
                onClick={() => onRemoveVisit(visitedReview.placeId)}
                className="min-h-[44px] px-3 rounded-xl bg-white border border-[#E3DFD6] text-xs font-semibold text-[#6E6C66] hover:text-[#E84231] hover:border-[#F5CFCB] flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Remove Dot</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => onOpenRate(activePlace)}
              className="flex-1 min-h-[48px] px-4 rounded-xl bg-[#0E7C58] hover:bg-[#0A6245] text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors active:scale-[0.99] shadow-sm whitespace-nowrap"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>I&apos;ve Been Here — Rate &amp; Pin Dot</span>
            </button>
            {onFocusOnMap && (
              <button
                type="button"
                onClick={() => onFocusOnMap(activePlace)}
                className="min-h-[48px] px-4 rounded-xl border border-[#E3DFD6] text-sm font-semibold text-[#141311] hover:bg-[#F6F4EF] whitespace-nowrap"
              >
                Show on Map
              </button>
            )}
          </div>
        )}

        {loadingDetails && !activePlace.editorialSummary && (
          <p className="text-xs text-[#7A766E]">Loading extra details...</p>
        )}

        {activePlace.editorialSummary && (
          <div className="pt-2 border-t border-[#ECE9E1]">
            <h4 className="text-xs font-semibold text-[#7A766E] mb-1">
              About this spot
            </h4>
            <p className="text-sm text-[#35332F] leading-relaxed">
              {activePlace.editorialSummary}
            </p>
          </div>
        )}

        {activePlace.reviews && activePlace.reviews.length > 0 && (
          <div className="pt-2 border-t border-[#ECE9E1] space-y-2.5">
            <h4 className="text-xs font-semibold text-[#7A766E]">
              Recent Google diner notes
            </h4>
            {activePlace.reviews.slice(0, 2).map((rev, i) => (
              <div key={i} className="text-xs text-[#45433E] space-y-0.5">
                <div className="flex items-center gap-2 font-medium text-[#141311]">
                  <span>{rev.authorName || 'Google diner'}</span>
                  {rev.rating && (
                    <span className="font-mono tabular-nums">{rev.rating.toFixed(1)} ★</span>
                  )}
                  {rev.relativePublishTimeDescription && (
                    <span className="text-[#8E8B84] font-normal">
                      · {rev.relativePublishTimeDescription}
                    </span>
                  )}
                </div>
                {rev.text && (
                  <p className="line-clamp-3 leading-relaxed text-[#52504A]">
                    {rev.text}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}

        {activePlace.attributions && activePlace.attributions.length > 0 && (
          <p className="text-[11px] text-[#8E8B84] pt-2 border-t border-[#ECE9E1]">
            Data attribution:{' '}
            {activePlace.attributions.map((a) => a.provider).join(', ')}
          </p>
        )}
      </div>
    </motion.div>
  );
};
