import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useMapsLibrary } from '@vis.gl/react-google-maps';
import { motion } from 'motion/react';
import {
  CheckCircle2,
  Compass,
  Globe,
  MapPin,
  RefreshCw,
  SlidersHorizontal,
  Utensils,
} from 'lucide-react';
import { TASTE_LIKING_OPTIONS } from '../data/foodData';
import { searchFoodByText } from '../services/placesService';
import type {
  FoodPlace,
  SelectedDestination,
  TasteRecommendation,
  VisitedReview,
} from '../types/food';

interface RecommendationsViewProps {
  destination: SelectedDestination;
  onOpenDestinationPicker: () => void;
  tasteLikings: string[];
  onToggleLiking: (likingId: string) => void;
  visitedReviews: VisitedReview[];
  discoveredPlaces: FoodPlace[];
  onPlacesDiscovered: (places: FoodPlace[]) => void;
  recommendations: TasteRecommendation[];
  onRecommendationsLoaded: (recs: TasteRecommendation[]) => void;
  onSelectAndFocusMap: (place: FoodPlace) => void;
  onOpenRate: (place: FoodPlace) => void;
}

export const RecommendationsView: React.FC<RecommendationsViewProps> = ({
  destination,
  onOpenDestinationPicker,
  tasteLikings,
  onToggleLiking,
  visitedReviews,
  discoveredPlaces,
  onPlacesDiscovered,
  recommendations,
  onRecommendationsLoaded,
  onSelectAndFocusMap,
  onOpenRate,
}) => {
  const placesLib = useMapsLibrary('places');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showLikingEditor, setShowLikingEditor] = useState(false);
  const lastRecDestinationRef = useRef<string>('');

  const destinationContext = useMemo(
    () => ({
      city: destination.cityName,
      country: destination.countryName,
      countryCode: destination.countryCode,
    }),
    [destination.cityName, destination.countryName, destination.countryCode]
  );

  const visitedIdSet = useMemo(
    () => new Set(visitedReviews.map((r) => r.placeId)),
    [visitedReviews]
  );

  const learnedTasteTags = useMemo(() => {
    const counts: Record<string, number> = {};
    visitedReviews
      .filter((r) => r.overallRating >= 4)
      .forEach((r) => {
        r.tasteTags.forEach((tag) => {
          counts[tag] = (counts[tag] || 0) + 1;
        });
      });
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([tag]) => tag);
  }, [visitedReviews]);

  const placeById = useMemo(() => {
    const record: Record<string, FoodPlace> = {};
    discoveredPlaces.forEach((p) => {
      record[p.id] = p;
    });
    return record;
  }, [discoveredPlaces]);

  const generatePicks = useCallback(async () => {
    if (!placesLib) {
      setErrorMsg('Google Places is still loading. Try again in a moment.');
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);

    try {
      const selectedOptions = TASTE_LIKING_OPTIONS.filter((opt) =>
        tasteLikings.includes(opt.id)
      );

      const citySuffix = `${destination.cityName}, ${destination.countryName}`;
      const queries =
        selectedOptions.length > 0
          ? selectedOptions.slice(0, 2).map((o) => `${o.searchHint} in ${citySuffix}`)
          : [`best rated restaurants and cafes in ${citySuffix}`];

      const searchBatches = await Promise.all(
        queries.map((q) =>
          searchFoodByText(placesLib, {
            textQuery: q,
            center: destination.center,
            regionCode: destination.countryCode,
            destinationContext,
            maxResultCount: 10,
          })
        )
      );

      const batchPlaces = searchBatches.flat();
      onPlacesDiscovered(batchPlaces);

      const mergedById: Record<string, FoodPlace> = {};
      [...discoveredPlaces, ...batchPlaces].forEach((p) => {
        mergedById[p.id] = p;
      });

      const unvisitedCandidates = Object.values(mergedById)
        .filter((p) => !visitedIdSet.has(p.id))
        .slice(0, 18);

      if (unvisitedCandidates.length === 0) {
        setErrorMsg(
          `You have visited all currently discovered spots in ${destination.cityName}! Search another area or switch cities to discover more.`
        );
        setIsLoading(false);
        return;
      }

      const likingLabels = [
        ...selectedOptions.map((o) => o.label),
        ...learnedTasteTags,
      ];

      const res = await fetch('/api/recommendations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          city: destination.cityName,
          country: destination.countryName,
          tasteLikings: likingLabels,
          visitedReviews,
          candidatePlaces: unvisitedCandidates.map((p) => ({
            placeId: p.id,
            displayName: p.displayName,
            formattedAddress: p.formattedAddress,
            primaryTypeLabel: p.primaryTypeLabel,
            types: p.types,
            rating: p.rating,
            userRatingCount: p.userRatingCount,
            priceLevel: p.priceLevel,
          })),
        }),
      });

      const payload = await res.json();
      if (!res.ok) {
        throw new Error(payload.error || 'Could not compute recommendations.');
      }

      onRecommendationsLoaded(payload.recommendations ?? []);
    } catch (err) {
      setErrorMsg(
        err instanceof Error
          ? err.message
          : `Failed to load personalized ${destination.cityName} recommendations.`
      );
    } finally {
      setIsLoading(false);
    }
  }, [
    placesLib,
    tasteLikings,
    destination.cityName,
    destination.countryName,
    destination.countryCode,
    destination.center,
    destinationContext,
    discoveredPlaces,
    visitedIdSet,
    learnedTasteTags,
    visitedReviews,
    onPlacesDiscovered,
    onRecommendationsLoaded,
  ]);

  useEffect(() => {
    if (!placesLib || isLoading) return;
    if (
      lastRecDestinationRef.current !== destination.id ||
      (recommendations.length === 0 && !errorMsg)
    ) {
      lastRecDestinationRef.current = destination.id;
      void generatePicks();
    }
  }, [
    placesLib,
    destination.id,
    recommendations.length,
    isLoading,
    errorMsg,
    generatePicks,
  ]);

  const resolvedRecommendations = useMemo(() => {
    return recommendations
      .map((rec) => {
        const place = placeById[rec.placeId];
        if (!place || visitedIdSet.has(rec.placeId)) return null;
        return { rec, place };
      })
      .filter(
        (item): item is { rec: TasteRecommendation; place: FoodPlace } =>
          item !== null
      );
  }, [recommendations, placeById, visitedIdSet]);

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-8">
      {/* Dark Editorial Showcase Banner */}
      <div className="relative rounded-2xl overflow-hidden bg-[#141311] text-white border border-[#2A2824] shadow-md">
        <img
          src="/src/assets/images/sydney_dining_hero_1795230487718.jpg"
          alt="Culinary dining showcase"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover opacity-35"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#141311] via-[#141311]/90 to-[#141311]/55" />

        <div className="relative z-10 p-5 sm:p-7 flex flex-col md:flex-row md:items-end justify-between gap-5">
          <div className="space-y-2 max-w-2xl">
            <p className="text-xs font-mono uppercase tracking-wider text-[#FF7B6B]">
              Curated For {destination.cityName}, {destination.countryName}
            </p>
            <h1 className="text-2xl sm:text-4xl font-bold text-white tracking-tight text-balance">
              Next stops in {destination.cityName}, matched to your likings
            </h1>
            <p className="text-sm text-white/75 leading-relaxed">
              Real unvisited spots in {destination.cityName} ranked against your cravings and places you rated 4.0 stars or higher.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={onOpenDestinationPicker}
              className="min-h-[44px] px-4 rounded-xl border border-white/20 bg-white/10 backdrop-blur-md text-xs font-semibold text-white hover:bg-white/20 flex items-center gap-2 whitespace-nowrap"
            >
              <Globe className="w-4 h-4 text-[#34D399]" />
              <span>Change City</span>
            </button>
            <button
              type="button"
              onClick={() => setShowLikingEditor((v) => !v)}
              className="min-h-[44px] px-4 rounded-xl border border-white/20 bg-white/10 backdrop-blur-md text-xs font-semibold text-white hover:bg-white/20 flex items-center gap-2 whitespace-nowrap"
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>Tune Likings ({tasteLikings.length})</span>
            </button>
            <button
              type="button"
              onClick={generatePicks}
              disabled={isLoading || !placesLib}
              className="min-h-[44px] px-4 rounded-xl bg-[#E84231] hover:bg-[#D13322] disabled:opacity-60 text-white text-xs font-semibold flex items-center gap-2 transition-colors whitespace-nowrap shadow-md"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              <span>{isLoading ? 'Matching...' : 'Refresh Picks'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Interactive Taste Likings Bar */}
      {(showLikingEditor || tasteLikings.length === 0) && (
        <div className="bg-white border border-[#E3DFD6] rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h2 className="text-sm font-bold text-[#141311]">
                Select what you&apos;re craving in {destination.cityName}
              </h2>
              <p className="text-xs text-[#6E6C66]">
                Toggle styles below, then tap Refresh Picks to update your matches.
              </p>
            </div>
            {learnedTasteTags.length > 0 && (
              <p className="hidden sm:block text-xs text-[#0E7C58] font-medium">
                Learned: {learnedTasteTags.join(' · ')}
              </p>
            )}
          </div>

          <div className="flex flex-wrap gap-2">
            {TASTE_LIKING_OPTIONS.map((opt) => {
              const active = tasteLikings.includes(opt.id);
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onToggleLiking(opt.id)}
                  className={`min-h-[40px] px-3.5 rounded-xl text-xs font-semibold border transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-[#141311] border-[#141311] text-white'
                      : 'bg-[#F6F4EF] border-[#E3DFD6] text-[#35332F] hover:border-[#141311]'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Unboxed Active Taste Summary */}
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[#6E6C66] px-1">
        <span className="font-semibold text-[#141311]">Active cravings:</span>
        <span>
          {TASTE_LIKING_OPTIONS.filter((o) => tasteLikings.includes(o.id))
            .map((o) => o.label)
            .join(' · ') || 'General local highlights'}
        </span>
        {learnedTasteTags.length > 0 && (
          <>
            <span aria-hidden="true">/</span>
            <span className="text-[#0E7C58] font-semibold">
              High-rated signals: {learnedTasteTags.join(' · ')}
            </span>
          </>
        )}
      </div>

      {errorMsg && (
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <span>{errorMsg}</span>
          <button
            type="button"
            onClick={generatePicks}
            className="min-h-[40px] px-4 rounded-xl bg-amber-900 text-white text-xs font-semibold self-start sm:self-auto whitespace-nowrap"
          >
            Try Again
          </button>
        </div>
      )}

      {isLoading && resolvedRecommendations.length === 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div
              key={n}
              className="bg-white border border-[#E3DFD6] rounded-2xl overflow-hidden h-80 animate-pulse"
            >
              <div className="h-44 bg-[#EDEAE3]" />
              <div className="p-4 space-y-3">
                <div className="h-4 w-2/3 bg-[#EDEAE3] rounded" />
                <div className="h-3 w-1/2 bg-[#F3F0EA] rounded" />
                <div className="h-12 w-full bg-[#F3F0EA] rounded" />
              </div>
            </div>
          ))}
        </div>
      ) : resolvedRecommendations.length === 0 ? (
        <div className="bg-white border border-[#E3DFD6] rounded-2xl p-10 text-center space-y-3">
          <Compass className="w-8 h-8 text-[#6E6C66] mx-auto" />
          <h3 className="text-lg font-bold text-[#141311]">
            Ready to match your next meal in {destination.cityName}
          </h3>
          <p className="text-sm text-[#6E6C66] max-w-md mx-auto">
            Choose a couple of cravings above and tap Refresh Picks to rank real unvisited spots in {destination.cityName}, {destination.countryName}.
          </p>
          <button
            type="button"
            onClick={generatePicks}
            disabled={!placesLib}
            className="min-h-[44px] px-5 rounded-xl bg-[#E84231] text-white text-sm font-semibold inline-flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Find My {destination.cityName} Picks</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {resolvedRecommendations.map(({ rec, place }, idx) => (
            <motion.article
              key={place.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2, delay: idx * 0.04, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -2 }}
              className="bg-white border border-[#E3DFD6] rounded-2xl overflow-hidden flex flex-col shadow-xs hover:shadow-md transition-all"
            >
              <div className="relative h-48 bg-[#1C1B18] overflow-hidden">
                {place.photoUri ? (
                  <img
                    src={place.photoUri}
                    alt={place.displayName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-[#A8A39A]">
                    <Utensils className="w-8 h-8 opacity-50" />
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent" />
                <div className="absolute top-3 right-3 px-2.5 py-1 rounded-lg bg-[#141311]/85 backdrop-blur-md border border-white/15 text-white font-mono tabular-nums text-xs font-bold">
                  {rec.matchScore}% match
                </div>
                <div className="absolute bottom-3 left-4 right-4 text-white">
                  <h3 className="text-lg font-bold leading-snug truncate">
                    {place.displayName}
                  </h3>
                  <p className="text-xs text-white/85 mt-0.5 truncate">
                    {place.locality} · {place.primaryTypeLabel}
                    {place.priceLevel ? ` · ${place.priceLevel}` : ''}
                    {place.rating ? ` · ${place.rating.toFixed(1)} ★` : ''}
                  </p>
                </div>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between gap-4">
                <div className="space-y-2.5">
                  <div className="h-1 w-full bg-[#EFECE5] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#E84231] rounded-full"
                      style={{ width: `${rec.matchScore}%` }}
                    />
                  </div>
                  <p className="text-sm text-[#292826] leading-relaxed">
                    {rec.matchReason}
                  </p>
                  {rec.suggestedOrder && (
                    <p className="text-xs text-[#6E6C66]">
                      Look for: <span className="font-semibold text-[#141311]">{rec.suggestedOrder}</span>
                    </p>
                  )}
                  {place.photoAttributions && place.photoAttributions.length > 0 && (
                    <p className="text-[11px] text-[#8E8B84]">
                      Photo:{' '}
                      {place.photoAttributions
                        .map((a) => a.displayName)
                        .filter(Boolean)
                        .join(', ') || 'Google Maps'}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-[#EFECE5]">
                  <button
                    type="button"
                    onClick={() => onSelectAndFocusMap(place)}
                    className="flex-1 min-h-[44px] px-3 rounded-xl border border-[#E3DFD6] text-xs font-semibold text-[#141311] hover:bg-[#F6F4EF] flex items-center justify-center gap-1.5 whitespace-nowrap"
                  >
                    <MapPin className="w-3.5 h-3.5" />
                    <span>Show on Map</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenRate(place)}
                    className="flex-1 min-h-[44px] px-3 rounded-xl bg-[#0E7C58] hover:bg-[#0A6245] text-white text-xs font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Been Here</span>
                  </button>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      )}
    </div>
  );
};
