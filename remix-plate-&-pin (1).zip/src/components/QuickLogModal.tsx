import React, { useState } from 'react';
import { useMapsLibrary } from '@vis.gl/react-google-maps';
import { motion } from 'motion/react';
import { Globe, Search, Utensils, X } from 'lucide-react';
import { useAutocompleteSuggestions } from '../hooks/useAutocompleteSuggestions';
import {
  normalizeGooglePlace,
  searchFoodByText,
} from '../services/placesService';
import type { FoodPlace, SelectedDestination } from '../types/food';

interface QuickLogModalProps {
  destination: SelectedDestination;
  onClose: () => void;
  onPlaceChosenForRating: (place: FoodPlace) => void;
  onOpenDestinationPicker: () => void;
}

export const QuickLogModal: React.FC<QuickLogModalProps> = ({
  destination,
  onClose,
  onPlaceChosenForRating,
  onOpenDestinationPicker,
}) => {
  const placesLib = useMapsLibrary('places');
  const [query, setQuery] = useState('');
  const [textResults, setTextResults] = useState<FoodPlace[]>([]);
  const [searching, setSearching] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const destinationContext = {
    city: destination.cityName,
    country: destination.countryName,
    countryCode: destination.countryCode,
  };

  const { suggestions, isLoading, resetSession } = useAutocompleteSuggestions(
    query,
    {
      mode: 'food',
      center: destination.center,
      countryCode: destination.countryCode,
    }
  );

  const handleSelectSuggestion = async (
    suggestion: google.maps.places.AutocompleteSuggestion
  ) => {
    if (!suggestion.placePrediction) return;
    try {
      const place = suggestion.placePrediction.toPlace();
      await place.fetchFields({
        fields: [
          'id',
          'displayName',
          'formattedAddress',
          'addressComponents',
          'location',
          'primaryType',
          'primaryTypeDisplayName',
          'types',
          'rating',
          'userRatingCount',
          'priceLevel',
          'photos',
          'googleMapsURI',
        ],
      });
      const normalized = normalizeGooglePlace(place, destinationContext);
      resetSession();
      if (normalized) {
        onPlaceChosenForRating(normalized);
      }
    } catch {
      setErrorMsg('Could not load details for that spot.');
    }
  };

  const handleTextSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!placesLib || !query.trim()) return;
    setSearching(true);
    setErrorMsg(null);
    try {
      const results = await searchFoodByText(placesLib, {
        textQuery: `${query.trim()} in ${destination.cityName}, ${destination.countryName}`,
        center: destination.center,
        regionCode: destination.countryCode,
        destinationContext,
        maxResultCount: 8,
      });
      setTextResults(results);
    } catch {
      setErrorMsg('Search failed. Please try again.');
    } finally {
      setSearching(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.16 }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="quick-log-title"
    >
      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
        className="w-full sm:max-w-lg bg-white rounded-t-3xl sm:rounded-2xl shadow-2xl border border-[#E3DFD6] max-h-[88vh] flex flex-col overflow-hidden"
      >
        <div className="sm:hidden pt-2.5 pb-1 flex justify-center">
          <div className="w-10 h-1.5 rounded-full bg-[#D8D4CC]" />
        </div>

        <div className="bg-[#141311] text-white flex items-center justify-between px-5 py-4 gap-3">
          <div className="min-w-0">
            <h2 id="quick-log-title" className="text-lg font-bold text-white truncate">
              Log a Visit in {destination.cityName}
            </h2>
            <p className="text-xs text-white/70 truncate">
              Find any restaurant, cafe, or bakery in {destination.cityName}, {destination.countryName}.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close search modal"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-white/75 hover:bg-white/10 hover:text-white shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 overflow-y-auto">
          <div className="flex items-center justify-between gap-2 text-xs text-[#52504A] bg-[#F6F4EF] border border-[#E3DFD6] rounded-xl px-3.5 py-2">
            <span className="inline-flex items-center gap-1.5 font-medium truncate">
              <Globe className="w-3.5 h-3.5 text-[#0E7C58] shrink-0" />
              <span className="truncate">
                Searching in {destination.cityName}, {destination.countryName}
              </span>
            </span>
            <button
              type="button"
              onClick={onOpenDestinationPicker}
              className="font-semibold text-[#E84231] hover:underline shrink-0"
            >
              Change City
            </button>
          </div>

          <form onSubmit={handleTextSearch} className="flex gap-2">
            <div className="flex-1 flex items-center bg-[#F6F4EF] border border-[#E3DFD6] rounded-xl px-3 focus-within:border-[#141311] focus-within:bg-white">
              <Search className="w-4 h-4 text-[#6E6C66] shrink-0" />
              <input
                type="text"
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={`Type a restaurant or cafe in ${destination.cityName}...`}
                className="w-full min-h-[44px] px-2.5 bg-transparent text-sm text-[#141311] placeholder:text-[#8E8B84] focus:outline-none"
              />
            </div>
            <button
              type="submit"
              disabled={searching || !query.trim()}
              className="min-h-[44px] px-4 rounded-xl bg-[#E84231] hover:bg-[#D13322] text-white text-xs font-semibold disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              {searching ? 'Searching...' : 'Search'}
            </button>
          </form>

          {errorMsg && <p className="text-xs text-[#E84231]">{errorMsg}</p>}

          {(isLoading || searching) && (
            <p className="text-xs text-[#6E6C66]">
              Searching {destination.cityName} spots...
            </p>
          )}

          {suggestions.length > 0 && (
            <div className="space-y-1.5">
              <p className="text-xs font-semibold text-[#6E6C66]">
                Suggestions in {destination.cityName}
              </p>
              <div className="divide-y divide-[#F3F0EA] border border-[#E3DFD6] rounded-xl overflow-hidden">
                {suggestions.map((s, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => void handleSelectSuggestion(s)}
                    className="w-full text-left px-3.5 py-3 hover:bg-[#F6F4EF] flex items-center justify-between gap-3 min-h-[48px]"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Utensils className="w-4 h-4 text-[#0E7C58] shrink-0" />
                      <span className="text-sm font-medium text-[#141311] truncate">
                        {s.placePrediction?.text.text}
                      </span>
                    </div>
                    <span className="text-xs font-semibold text-[#0E7C58] shrink-0">
                      Select →
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {textResults.length > 0 && (
            <div className="space-y-1.5">
              <p className="text-xs font-semibold text-[#6E6C66]">
                Search results
              </p>
              <div className="divide-y divide-[#F3F0EA] border border-[#E3DFD6] rounded-xl overflow-hidden">
                {textResults.map((place) => (
                  <button
                    key={place.id}
                    type="button"
                    onClick={() => onPlaceChosenForRating(place)}
                    className="w-full text-left px-3.5 py-3 hover:bg-[#F6F4EF] flex items-center justify-between gap-3 min-h-[52px]"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[#141311] truncate">
                        {place.displayName}
                      </p>
                      <p className="text-xs text-[#6E6C66] truncate">
                        {place.locality} · {place.primaryTypeLabel}
                      </p>
                    </div>
                    <span className="text-xs font-semibold text-[#0E7C58] shrink-0">
                      Rate →
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
};
