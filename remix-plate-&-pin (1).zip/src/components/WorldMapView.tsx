import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AdvancedMarker,
  ColorScheme,
  InfoWindow,
  Map as GoogleMap,
  useAdvancedMarkerRef,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import {
  Check,
  ChevronDown,
  Compass,
  Globe,
  LocateFixed,
  Moon,
  RefreshCw,
  Search,
  Star,
  Sun,
  Utensils,
} from 'lucide-react';
import { MAP_CATEGORY_FILTERS } from '../data/foodData';
import { useAutocompleteSuggestions } from '../hooks/useAutocompleteSuggestions';
import {
  ATTRIBUTION_ID,
  normalizeGooglePlace,
  searchFoodByText,
  searchNearbyFood,
} from '../services/placesService';
import type {
  FoodPlace,
  LatLngPoint,
  MapPinFilter,
  SelectedDestination,
  TasteRecommendation,
  VisitedReview,
} from '../types/food';
import { PlaceDetailSheet } from './PlaceDetailSheet';

interface WorldMapViewProps {
  destination: SelectedDestination;
  onOpenDestinationPicker: () => void;
  discoveredPlaces: FoodPlace[];
  onPlacesDiscovered: (places: FoodPlace[], replaceCityFeed?: boolean) => void;
  visitedByPlaceId: Record<string, VisitedReview>;
  recommendationsByPlaceId: Record<string, TasteRecommendation>;
  selectedPlace: FoodPlace | null;
  onSelectPlace: (place: FoodPlace | null) => void;
  onOpenRate: (place: FoodPlace) => void;
  onRemoveVisit: (placeId: string) => void;
  focusRequest: { center: LatLngPoint; zoom?: number; timestamp: number } | null;
}

interface MarkerWithRefProps {
  place: FoodPlace;
  isVisited: boolean;
  isRecommended: boolean;
  isSelected: boolean;
  userRating?: number;
  zIndex: number;
  onMarkerClick: (
    place: FoodPlace,
    marker: google.maps.marker.AdvancedMarkerElement
  ) => void;
}

const WorldFoodMarker: React.FC<MarkerWithRefProps> = ({
  place,
  isVisited,
  isRecommended,
  isSelected,
  userRating,
  zIndex,
  onMarkerClick,
}) => {
  const [markerRef, marker] = useAdvancedMarkerRef();

  return (
    <AdvancedMarker
      ref={markerRef}
      position={place.location}
      zIndex={zIndex}
      title={place.displayName}
      onClick={() => {
        if (marker) {
          onMarkerClick(place, marker);
        }
      }}
    >
      {isVisited ? (
        <div
          className={`flex items-center gap-1.5 rounded-full border-2 border-white transition-transform duration-150 ${
            isSelected
              ? 'scale-125 bg-[#0A6245] px-2.5 py-1 shadow-[0_0_0_5px_rgba(16,185,129,0.28)]'
              : 'bg-[#0E7C58] px-2 py-1 shadow-[0_0_0_3px_rgba(16,185,129,0.18)] hover:scale-110'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-[#6EE7B7] shrink-0" />
          <span className="text-[11px] font-mono font-bold text-white leading-none tabular-nums">
            {userRating ? userRating.toFixed(1) : '✓'}
          </span>
        </div>
      ) : isRecommended ? (
        <div
          className={`flex items-center justify-center rounded-full border-2 border-white transition-transform duration-150 ${
            isSelected
              ? 'w-9 h-9 scale-115 bg-[#E84231] shadow-[0_0_0_5px_rgba(232,66,49,0.28)]'
              : 'w-7 h-7 bg-[#E84231] shadow-md hover:scale-110'
          }`}
        >
          <Star className="w-3.5 h-3.5 text-white fill-white" />
        </div>
      ) : (
        <div
          className={`flex items-center justify-center rounded-full border-2 border-white shadow-md transition-transform duration-150 ${
            isSelected
              ? 'w-8 h-8 scale-115 bg-[#141311] ring-4 ring-[#141311]/20'
              : 'w-6 h-6 bg-[#1C1B18] hover:scale-110'
          }`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-white/90" />
        </div>
      )}
    </AdvancedMarker>
  );
};

export const WorldMapView: React.FC<WorldMapViewProps> = ({
  destination,
  onOpenDestinationPicker,
  discoveredPlaces,
  onPlacesDiscovered,
  visitedByPlaceId,
  recommendationsByPlaceId,
  selectedPlace,
  onSelectPlace,
  onOpenRate,
  onRemoveVisit,
  focusRequest,
}) => {
  const map = useMap();
  const placesLib = useMapsLibrary('places');

  const [pinFilter, setPinFilter] = useState<MapPinFilter>('all');
  const [activeCategoryId, setActiveCategoryId] = useState<string>('all-dining');
  const [mapNightMode, setMapNightMode] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchFocused, setSearchFocused] = useState(false);
  const [isSearchingPlaces, setIsSearchingPlaces] = useState(false);
  const [placesError, setPlacesError] = useState<string | null>(null);
  const [showSearchAreaBtn, setShowSearchAreaBtn] = useState(false);

  const [infoWindowPlace, setInfoWindowPlace] = useState<FoodPlace | null>(null);
  const [infoWindowAnchor, setInfoWindowAnchor] =
    useState<google.maps.marker.AdvancedMarkerElement | null>(null);

  const lastLoadedDestinationRef = useRef<string>('');

  const destinationContext = useMemo(
    () => ({
      city: destination.cityName,
      country: destination.countryName,
      countryCode: destination.countryCode,
    }),
    [destination.cityName, destination.countryName, destination.countryCode]
  );

  const { suggestions, resetSession } = useAutocompleteSuggestions(searchQuery, {
    mode: 'food',
    countryCode: destination.countryCode,
    center: map?.getCenter()?.toJSON() ?? destination.center,
  });

  const runDiscovery = useCallback(
    async (
      center: LatLngPoint,
      categoryId: string,
      radiusMeters = 2600,
      replaceCityFeed = false
    ) => {
      if (!placesLib) return;
      const category =
        MAP_CATEGORY_FILTERS.find((c) => c.id === categoryId) ??
        MAP_CATEGORY_FILTERS[0];

      setIsSearchingPlaces(true);
      setPlacesError(null);
      try {
        const results = category.textQuery
          ? await searchFoodByText(placesLib, {
              textQuery: `${category.textQuery} in ${destination.cityName}, ${destination.countryName}`,
              center,
              radiusMeters,
              maxResultCount: 18,
              regionCode: destination.countryCode,
              destinationContext,
            })
          : await searchNearbyFood(placesLib, {
              center,
              radiusMeters,
              includedPrimaryTypes: category.includedPrimaryTypes,
              maxResultCount: 18,
              regionCode: destination.countryCode,
              destinationContext,
            });
        onPlacesDiscovered(results, replaceCityFeed);
      } catch (err) {
        setPlacesError(
          err instanceof Error
            ? err.message
            : `Unable to load food places in ${destination.cityName} right now.`
        );
      } finally {
        setIsSearchingPlaces(false);
        setShowSearchAreaBtn(false);
      }
    },
    [
      placesLib,
      destination.cityName,
      destination.countryName,
      destination.countryCode,
      destinationContext,
      onPlacesDiscovered,
    ]
  );

  useEffect(() => {
    if (!placesLib) return;
    if (lastLoadedDestinationRef.current === destination.id) return;
    lastLoadedDestinationRef.current = destination.id;

    setInfoWindowPlace(null);
    setInfoWindowAnchor(null);
    setSearchQuery('');
    setActiveCategoryId('all-dining');

    if (map) {
      map.panTo(destination.center);
      map.setZoom(13);
    }

    void runDiscovery(destination.center, 'all-dining', 2800, true);
  }, [placesLib, destination.id, destination.center, map, runDiscovery]);

  useEffect(() => {
    if (!map || !focusRequest) return;
    map.panTo(focusRequest.center);
    if (focusRequest.zoom) {
      map.setZoom(focusRequest.zoom);
    }
  }, [map, focusRequest]);

  const handleCategoryClick = (categoryId: string) => {
    setActiveCategoryId(categoryId);
    const center = map?.getCenter()?.toJSON() ?? destination.center;
    void runDiscovery(center, categoryId, 2600, false);
  };

  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = searchQuery.trim();
    if (!trimmed || !placesLib) return;

    setIsSearchingPlaces(true);
    setPlacesError(null);
    setSearchFocused(false);
    try {
      const results = await searchFoodByText(placesLib, {
        textQuery: `${trimmed} in ${destination.cityName}, ${destination.countryName}`,
        center: map?.getCenter()?.toJSON() ?? destination.center,
        maxResultCount: 14,
        regionCode: destination.countryCode,
        destinationContext,
      });
      onPlacesDiscovered(results, false);
      if (results.length > 0) {
        onSelectPlace(results[0]);
        map?.panTo(results[0].location);
        map?.setZoom(15);
      }
      resetSession();
    } catch (err) {
      setPlacesError(
        err instanceof Error ? err.message : 'Search failed. Please try again.'
      );
    } finally {
      setIsSearchingPlaces(false);
    }
  };

  const handleSuggestionPick = async (
    suggestion: google.maps.places.AutocompleteSuggestion
  ) => {
    if (!suggestion.placePrediction) return;
    setSearchFocused(false);
    try {
      const place = suggestion.placePrediction.toPlace();
      await place.fetchFields({
        fields: [
          'id',
          'displayName',
          'formattedAddress',
          'addressComponents',
          'location',
          'primaryType',
          'primaryTypeDisplayName',
          'types',
          'rating',
          'userRatingCount',
          'priceLevel',
          'photos',
          'googleMapsURI',
        ],
      });
      const normalized = normalizeGooglePlace(place, destinationContext);
      if (normalized) {
        onPlacesDiscovered([normalized], false);
        onSelectPlace(normalized);
        map?.panTo(normalized.location);
        map?.setZoom(16);
      }
      setSearchQuery(normalized?.displayName ?? '');
      resetSession();
    } catch (err) {
      setPlacesError(
        err instanceof Error ? err.message : 'Could not load selected place.'
      );
    }
  };

  const handleSearchThisArea = () => {
    if (!map) return;
    const center = map.getCenter()?.toJSON() ?? destination.center;
    void runDiscovery(center, activeCategoryId, 2400, false);
  };

  const handleLocateMe = () => {
    if (!navigator.geolocation || !map) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const pt = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        map.panTo(pt);
        map.setZoom(15);
        void runDiscovery(pt, activeCategoryId, 2000, false);
      },
      () => {
        map.panTo(destination.center);
        map.setZoom(13);
      }
    );
  };

  const allMapPlaces = useMemo(() => {
    const byId: Record<string, FoodPlace> = {};
    for (const p of discoveredPlaces) {
      byId[p.id] = p;
    }
    for (const visit of Object.values(visitedByPlaceId)) {
      if (!byId[visit.placeId]) {
        byId[visit.placeId] = {
          id: visit.placeId,
          displayName: visit.placeName,
          formattedAddress: visit.formattedAddress,
          locality: visit.locality,
          city: visit.city,
          country: visit.country,
          countryCode: visit.countryCode,
          location: visit.location,
          primaryType: 'restaurant',
          primaryTypeLabel: visit.primaryTypeLabel,
          types: [],
          photoUri: visit.photoUri,
          photoAttributions: visit.photoAttributions,
          googleMapsURI: visit.googleMapsURI,
        };
      }
    }

    return Object.values(byId).filter((place) => {
      const visited = Boolean(visitedByPlaceId[place.id]);
      const recommended = Boolean(recommendationsByPlaceId[place.id]);
      if (pinFilter === 'visited') return visited;
      if (pinFilter === 'recommended') return recommended;
      return true;
    });
  }, [discoveredPlaces, visitedByPlaceId, recommendationsByPlaceId, pinFilter]);

  const sortedMarkers = useMemo(() => {
    return [...allMapPlaces].sort((a, b) => b.location.lat - a.location.lat);
  }, [allMapPlaces]);

  const visitedCount = Object.keys(visitedByPlaceId).length;

  return (
    <div className="flex flex-col lg:flex-row lg:h-full gap-4">
      {/* Left/Primary Map Surface */}
      <div className="relative flex-1 h-[56vh] min-h-[380px] lg:h-full rounded-2xl overflow-hidden border border-[#E3DFD6] bg-[#1C1B18] shadow-sm">
        <GoogleMap
          mapId="DEMO_MAP_ID"
          colorScheme={mapNightMode ? ColorScheme.DARK : ColorScheme.LIGHT}
          defaultCenter={destination.center}
          defaultZoom={13}
          gestureHandling="greedy"
          disableDefaultUI={true}
          internalUsageAttributionIds={[ATTRIBUTION_ID]}
          onDragend={() => setShowSearchAreaBtn(true)}
          onZoomChanged={() => setShowSearchAreaBtn(true)}
          style={{ width: '100%', height: '100%' }}
        >
          {sortedMarkers.map((place, index) => {
            const visit = visitedByPlaceId[place.id];
            const rec = recommendationsByPlaceId[place.id];
            const isSelected = selectedPlace?.id === place.id;
            const zIndex = isSelected ? 1000 : visit ? 500 + index : index;

            return (
              <WorldFoodMarker
                key={place.id}
                place={place}
                isVisited={Boolean(visit)}
                isRecommended={Boolean(rec)}
                isSelected={isSelected}
                userRating={visit?.overallRating}
                zIndex={zIndex}
                onMarkerClick={(clickedPlace, markerEl) => {
                  onSelectPlace(clickedPlace);
                  setInfoWindowPlace(clickedPlace);
                  setInfoWindowAnchor(markerEl);
                }}
              />
            );
          })}

          {infoWindowPlace && infoWindowAnchor && (
            <InfoWindow
              anchor={infoWindowAnchor}
              onCloseClick={() => {
                setInfoWindowPlace(null);
                setInfoWindowAnchor(null);
              }}
              maxWidth={240}
            >
              <div className="p-0.5 text-[#141311]">
                <p className="font-semibold text-sm leading-tight">
                  {infoWindowPlace.displayName}
                </p>
                <p className="text-xs text-[#6E6C66] mt-0.5">
                  {infoWindowPlace.locality} · {infoWindowPlace.primaryTypeLabel}
                </p>
                {visitedByPlaceId[infoWindowPlace.id] ? (
                  <p className="text-xs font-semibold text-[#0E7C58] mt-1">
                    Visited Dot · {visitedByPlaceId[infoWindowPlace.id].overallRating.toFixed(1)} ★
                  </p>
                ) : (
                  <button
                    type="button"
                    onClick={() => onOpenRate(infoWindowPlace)}
                    className="mt-1.5 text-xs font-semibold text-[#E84231] hover:underline"
                  >
                    + Check in &amp; rate
                  </button>
                )}
              </div>
            </InfoWindow>
          )}
        </GoogleMap>

        {/* Top Frosted Obsidian HUD */}
        <div className="absolute top-3 left-3 right-3 z-10 flex flex-col gap-2 pointer-events-none">
          <div className="flex flex-col xl:flex-row items-stretch xl:items-center gap-2 pointer-events-auto">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 flex-1 min-w-0">
              {/* Active Country & City Switcher */}
              <button
                type="button"
                onClick={onOpenDestinationPicker}
                className="min-h-[44px] px-3.5 rounded-xl bg-[#141311]/95 backdrop-blur-md border border-white/20 hover:border-white/45 text-white text-xs font-semibold shadow-lg flex items-center justify-between sm:justify-start gap-2 whitespace-nowrap shrink-0 transition-colors"
              >
                <span className="flex items-center gap-2 min-w-0">
                  <Globe className="w-4 h-4 text-[#34D399] shrink-0" />
                  <span className="truncate max-w-[180px]">
                    {destination.cityName}, {destination.countryCode}
                  </span>
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-white/70 shrink-0" />
              </button>

              {/* Search Input */}
              <form
                onSubmit={handleSearchSubmit}
                className="relative flex-1 max-w-md"
              >
                <div className="flex items-center bg-[#141311]/90 backdrop-blur-md border border-white/15 rounded-xl shadow-lg focus-within:border-white/40">
                  <Search className="w-4 h-4 text-white/65 ml-3.5 shrink-0" />
                  <input
                    type="text"
                    value={searchQuery}
                    onFocus={() => setSearchFocused(true)}
                    onBlur={() => window.setTimeout(() => setSearchFocused(false), 180)}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={`Search ${destination.cityName} restaurants, cafes, bakeries...`}
                    className="w-full min-h-[44px] px-3 bg-transparent text-sm text-white placeholder:text-white/55 focus:outline-none"
                  />
                  {searchQuery && (
                    <button
                      type="submit"
                      className="mr-1.5 px-3 min-h-[34px] rounded-lg bg-[#E84231] text-white text-xs font-semibold whitespace-nowrap shrink-0"
                    >
                      Find
                    </button>
                  )}
                </div>

                {searchFocused && suggestions.length > 0 && (
                  <ul className="absolute left-0 right-0 mt-1.5 bg-[#141311]/95 backdrop-blur-md border border-white/15 rounded-xl shadow-2xl overflow-hidden divide-y divide-white/10 z-30">
                    {suggestions.map((s, idx) => (
                      <li key={idx}>
                        <button
                          type="button"
                          onMouseDown={(e) => {
                            e.preventDefault();
                            void handleSuggestionPick(s);
                          }}
                          className="w-full text-left px-3.5 py-2.5 text-sm text-white hover:bg-white/10 transition-colors flex items-center gap-2.5 min-h-[44px]"
                        >
                          <Utensils className="w-3.5 h-3.5 text-[#34D399] shrink-0" />
                          <span className="truncate">{s.placePrediction?.text.text}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </form>
            </div>

            {/* Map Layer Segmented Filter */}
            <div className="flex items-center gap-1 p-1 bg-[#141311]/90 backdrop-blur-md border border-white/15 rounded-xl shadow-lg self-start">
              {[
                { id: 'all' as const, label: 'All' },
                { id: 'visited' as const, label: `Been Here (${visitedCount})` },
                { id: 'recommended' as const, label: 'For You' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setPinFilter(tab.id)}
                  className={`min-h-[36px] px-3 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    pinFilter === tab.id
                      ? tab.id === 'visited'
                        ? 'bg-[#0E7C58] text-white'
                        : tab.id === 'recommended'
                        ? 'bg-[#E84231] text-white'
                        : 'bg-white text-[#141311]'
                      : 'text-white/75 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Food Category Quick Strip */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pointer-events-auto pb-0.5">
            {MAP_CATEGORY_FILTERS.map((cat) => {
              const active = activeCategoryId === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => handleCategoryClick(cat.id)}
                  className={`min-h-[34px] px-3 rounded-lg text-xs font-semibold border shadow-sm transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-[#141311] border-[#141311] text-white'
                      : 'bg-white/95 backdrop-blur-md border-[#E3DFD6] text-[#292826] hover:border-[#141311]'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom Map Controls + Legend */}
        <div className="absolute bottom-3 left-3 right-3 z-10 flex items-center justify-between gap-2 pointer-events-none">
          <div className="flex items-center gap-3.5 px-3.5 py-2 rounded-xl bg-[#141311]/90 backdrop-blur-md border border-white/15 shadow-lg text-xs text-white/90 pointer-events-auto">
            <span className="flex items-center gap-1.5 whitespace-nowrap">
              <span className="w-3 h-3 rounded-full bg-[#0E7C58] border-2 border-white shadow-[0_0_0_2px_rgba(16,185,129,0.3)] inline-block" />
              <span>Visited dot</span>
            </span>
            <span className="flex items-center gap-1.5 whitespace-nowrap">
              <span className="w-3 h-3 rounded-full bg-[#E84231] border-2 border-white inline-block" />
              <span>For You</span>
            </span>
          </div>

          <div className="flex items-center gap-2 pointer-events-auto">
            {showSearchAreaBtn && (
              <button
                type="button"
                onClick={handleSearchThisArea}
                disabled={isSearchingPlaces}
                className="min-h-[40px] px-3.5 rounded-xl bg-[#E84231] hover:bg-[#D13322] text-white text-xs font-semibold shadow-lg flex items-center gap-1.5 whitespace-nowrap"
              >
                <RefreshCw
                  className={`w-3.5 h-3.5 ${isSearchingPlaces ? 'animate-spin' : ''}`}
                />
                <span>Search this area</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setMapNightMode((v) => !v)}
              aria-label={mapNightMode ? 'Switch to light map' : 'Switch to dark map'}
              title={mapNightMode ? 'Day map' : 'Night map'}
              className="min-h-[40px] px-3 rounded-xl bg-[#141311]/90 backdrop-blur-md border border-white/15 shadow-lg flex items-center gap-1.5 text-xs font-semibold text-white hover:bg-[#141311]"
            >
              {mapNightMode ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-300" />
                  <span className="hidden sm:inline">Day</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-white/80" />
                  <span className="hidden sm:inline">Night</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleLocateMe}
              aria-label="Center map near me"
              className="min-h-[40px] min-w-[40px] rounded-xl bg-[#141311]/90 backdrop-blur-md border border-white/15 shadow-lg flex items-center justify-center text-white hover:bg-[#141311]"
            >
              <LocateFixed className="w-4 h-4" />
            </button>
          </div>
        </div>

        {placesError && (
          <div className="absolute top-32 left-3 right-3 z-20 p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center justify-between gap-3">
            <span>{placesError}</span>
            <button
              type="button"
              onClick={() => setPlacesError(null)}
              className="font-semibold underline shrink-0"
            >
              Dismiss
            </button>
          </div>
        )}
      </div>

      {/* Right Side Discovery / Detail Drawer */}
      <div className="w-full lg:w-[400px] xl:w-[430px] shrink-0 flex flex-col gap-3 lg:h-full lg:overflow-hidden">
        {selectedPlace ? (
          <PlaceDetailSheet
            place={selectedPlace}
            visitedReview={visitedByPlaceId[selectedPlace.id]}
            recommendation={recommendationsByPlaceId[selectedPlace.id]}
            onClose={() => {
              onSelectPlace(null);
              setInfoWindowPlace(null);
            }}
            onOpenRate={onOpenRate}
            onRemoveVisit={onRemoveVisit}
          />
        ) : (
          <div className="bg-white border border-[#E3DFD6] rounded-2xl flex flex-col h-full overflow-hidden shadow-xs">
            <div className="bg-[#141311] text-white px-4 py-3.5 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <h2 className="text-base font-bold text-white truncate">
                  {destination.cityName} Feed ({allMapPlaces.length})
                </h2>
                <p className="text-xs text-white/65 truncate">
                  {destination.countryName} · Tap a spot to drop a green dot
                </p>
              </div>
              <button
                type="button"
                onClick={handleSearchThisArea}
                disabled={isSearchingPlaces}
                className="min-h-[38px] px-3 rounded-lg bg-white/10 hover:bg-white/20 border border-white/15 text-xs font-semibold text-white flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <Compass className="w-3.5 h-3.5" />
                <span>{isSearchingPlaces ? 'Loading...' : 'Refresh'}</span>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-[#EFECE5]">
              {isSearchingPlaces && allMapPlaces.length === 0 ? (
                <div className="p-5 space-y-3">
                  {[1, 2, 3, 4].map((i) => (
                    <div
                      key={i}
                      className="h-20 rounded-xl bg-[#F3F0EA] animate-pulse"
                    />
                  ))}
                </div>
              ) : allMapPlaces.length === 0 ? (
                <div className="p-8 text-center space-y-2">
                  <p className="text-sm font-semibold text-[#141311]">
                    No spots match this filter yet
                  </p>
                  <p className="text-xs text-[#6E6C66]">
                    Switch back to All or search an eatery in {destination.cityName} above to pin your first visited dot.
                  </p>
                </div>
              ) : (
                allMapPlaces.map((place) => {
                  const visit = visitedByPlaceId[place.id];
                  const rec = recommendationsByPlaceId[place.id];
                  return (
                    <div
                      key={place.id}
                      className={`p-3.5 transition-colors flex items-center gap-3 ${
                        visit ? 'bg-[#F0F7F4]/45 hover:bg-[#F0F7F4]' : 'hover:bg-[#F6F4EF]'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => {
                          onSelectPlace(place);
                          map?.panTo(place.location);
                        }}
                        className="flex-1 min-w-0 text-left flex items-center gap-3 group"
                      >
                        <div className="w-16 h-16 rounded-xl bg-[#EDEAE3] overflow-hidden shrink-0 relative">
                          {place.photoUri ? (
                            <img
                              src={place.photoUri}
                              alt={place.displayName}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-[#6E6C66]">
                              <Utensils className="w-5 h-5" />
                            </div>
                          )}
                          {visit && (
                            <span
                              title="Visited dot"
                              className="absolute top-1.5 left-1.5 w-5 h-5 rounded-full bg-[#0E7C58] border-2 border-white flex items-center justify-center shadow-xs"
                            >
                              <Check className="w-3 h-3 text-white stroke-[3]" />
                            </span>
                          )}
                        </div>

                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-bold text-[#141311] truncate">
                            {place.displayName}
                          </p>
                          <p className="text-xs text-[#6E6C66] truncate mt-0.5">
                            {place.locality} · {place.primaryTypeLabel}
                            {place.priceLevel ? ` · ${place.priceLevel}` : ''}
                          </p>
                          <div className="flex items-center gap-2 mt-1 text-xs">
                            {visit ? (
                              <span className="font-mono tabular-nums font-bold text-[#0E7C58]">
                                Your dot: {visit.overallRating.toFixed(1)} ★
                              </span>
                            ) : place.rating ? (
                              <span className="font-mono tabular-nums text-[#45433E]">
                                {place.rating.toFixed(1)} ★ Google
                              </span>
                            ) : null}
                            {rec && !visit && (
                              <span className="text-[#E84231] font-semibold font-mono tabular-nums">
                                · {rec.matchScore}% match
                              </span>
                            )}
                          </div>
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => onOpenRate(place)}
                        className={`min-h-[38px] px-3.5 rounded-xl text-xs font-semibold shrink-0 whitespace-nowrap transition-colors ${
                          visit
                            ? 'bg-[#0E7C58]/10 text-[#0E7C58] border border-[#0E7C58]/30 hover:bg-[#0E7C58]/15'
                            : 'bg-[#141311] text-white hover:bg-[#2C2A26]'
                        }`}
                      >
                        {visit ? 'Rated ✓' : 'Rate'}
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
