import React, { useMemo, useState } from 'react';
import { Check, Globe, Pencil } from 'lucide-react';
import { TASTE_LIKING_OPTIONS } from '../data/foodData';
import type { SelectedDestination, VisitedReview } from '../types/food';
import type { DinerProfile } from '../utils/storage';
import { InteractiveCheckBoard } from './InteractiveCheckBoard';

interface ProfileViewProps {
  destination: SelectedDestination;
  onOpenDestinationPicker: () => void;
  profile: DinerProfile;
  onUpdateProfile: (profile: DinerProfile) => void;
  tasteLikings: string[];
  onToggleLiking: (id: string) => void;
  visitedReviews: VisitedReview[];
  onJumpToPlaceOnMap: (review: VisitedReview) => void;
  onJumpToCityOnMap: (cityDest: SelectedDestination) => void;
  onEditReview: (review: VisitedReview) => void;
  onOpenQuickLog: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  destination,
  onOpenDestinationPicker,
  profile,
  onUpdateProfile,
  tasteLikings,
  onToggleLiking,
  visitedReviews,
  onJumpToPlaceOnMap,
  onJumpToCityOnMap,
  onEditReview,
  onOpenQuickLog,
}) => {
  const [editingProfile, setEditingProfile] = useState(false);
  const [draftName, setDraftName] = useState(profile.name);
  const [draftHomeCity, setDraftHomeCity] = useState(
    profile.homeCity || destination.cityName
  );
  const [draftHomeCountry, setDraftHomeCountry] = useState(
    profile.homeCountry || destination.countryName
  );
  const [draftBio, setDraftBio] = useState(profile.bio);

  const avgRating = useMemo(() => {
    if (visitedReviews.length === 0) return 0;
    const total = visitedReviews.reduce((acc, r) => acc + r.overallRating, 0);
    return total / visitedReviews.length;
  }, [visitedReviews]);

  const uniqueCitiesCount = useMemo(() => {
    return new Set(
      visitedReviews.map(
        (r) => `${r.city.toLowerCase()}|${r.countryCode.toLowerCase()}`
      )
    ).size;
  }, [visitedReviews]);

  const uniqueCountriesCount = useMemo(() => {
    return new Set(
      visitedReviews.map((r) => r.countryCode.toLowerCase()).filter(Boolean)
    ).size;
  }, [visitedReviews]);

  const wouldReturnCount = useMemo(() => {
    return visitedReviews.filter((r) => r.wouldReturn === 'yes').length;
  }, [visitedReviews]);

  const topTasteSignals = useMemo(() => {
    const counts: Record<string, number> = {};
    visitedReviews.forEach((r) => {
      r.tasteTags.forEach((t) => {
        counts[t] = (counts[t] || 0) + 1;
      });
    });
    const sorted = Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 4);
    const max = sorted[0]?.[1] || 1;
    return sorted.map(([tag, count]) => ({
      tag,
      count,
      pct: Math.round((count / max) * 100),
    }));
  }, [visitedReviews]);

  const saveProfileEdits = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      ...profile,
      name: draftName.trim() || profile.name,
      homeCity: draftHomeCity.trim(),
      homeCountry: draftHomeCountry.trim(),
      bio: draftBio.trim(),
    });
    setEditingProfile(false);
  };

  const displayCity = profile.homeCity || destination.cityName;
  const displayCountry = profile.homeCountry || destination.countryName;

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-10">
      {/* Global Tasting Passport Hero Card */}
      <div className="bg-white border border-[#E3DFD6] rounded-2xl overflow-hidden shadow-xs">
        <div className="relative h-48 sm:h-56 w-full bg-[#141311]">
          <img
            src="/src/assets/images/sydney_dining_hero_1795230487718.jpg"
            alt="Global dining table"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#141311]/85 via-black/30 to-transparent" />
          <div className="absolute top-4 left-5 text-white/90 font-mono text-xs tracking-wider uppercase">
            Global Member Passport
          </div>
          <img
            src="/src/assets/images/passport_stamp_emblem_1795230486755.jpg"
            alt="Plate and Pin emblem"
            referrerPolicy="no-referrer"
            className="absolute top-4 right-4 w-14 h-14 rounded-full border-2 border-white/85 object-cover shadow-lg"
          />
        </div>

        <div className="px-5 sm:px-6 pb-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-11 relative z-10">
            <div className="flex items-end gap-4">
              <img
                src="/src/assets/images/foodie_avatar_1795230487077.jpg"
                alt={profile.name}
                referrerPolicy="no-referrer"
                className="w-22 h-22 sm:w-24 sm:h-24 rounded-2xl border-4 border-white object-cover shadow-lg bg-[#EDEAE3]"
              />
              <div className="pb-1">
                <h1 className="text-2xl sm:text-3xl font-bold text-[#141311] leading-tight">
                  {profile.name}
                </h1>
                <p className="text-xs text-[#6E6C66] mt-0.5">
                  {profile.handle} · {displayCity}, {displayCountry}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
              <button
                type="button"
                onClick={onOpenDestinationPicker}
                className="min-h-[42px] px-4 rounded-xl border border-[#E3DFD6] bg-white hover:bg-[#F6F4EF] text-xs font-semibold text-[#141311] inline-flex items-center gap-1.5 whitespace-nowrap"
              >
                <Globe className="w-3.5 h-3.5 text-[#0E7C58]" />
                <span>
                  {destination.cityName}, {destination.countryCode}
                </span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setDraftName(profile.name);
                  setDraftHomeCity(profile.homeCity || destination.cityName);
                  setDraftHomeCountry(
                    profile.homeCountry || destination.countryName
                  );
                  setDraftBio(profile.bio);
                  setEditingProfile((v) => !v);
                }}
                className="min-h-[42px] px-4 rounded-xl border border-[#E3DFD6] bg-[#F6F4EF] hover:bg-[#EAE6DC] text-xs font-semibold text-[#141311] inline-flex items-center gap-1.5 whitespace-nowrap"
              >
                <Pencil className="w-3.5 h-3.5" />
                <span>{editingProfile ? 'Cancel Edit' : 'Edit Profile'}</span>
              </button>
            </div>
          </div>

          {editingProfile ? (
            <form
              onSubmit={saveProfileEdits}
              className="mt-4 pt-4 border-t border-[#E3DFD6] grid grid-cols-1 sm:grid-cols-3 gap-3"
            >
              <div>
                <label className="block text-xs font-semibold text-[#52504A] mb-1">
                  Display name
                </label>
                <input
                  type="text"
                  value={draftName}
                  onChange={(e) => setDraftName(e.target.value)}
                  className="w-full min-h-[44px] px-3 rounded-xl border border-[#E3DFD6] bg-[#F6F4EF] text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#52504A] mb-1">
                  Home city
                </label>
                <input
                  type="text"
                  value={draftHomeCity}
                  onChange={(e) => setDraftHomeCity(e.target.value)}
                  className="w-full min-h-[44px] px-3 rounded-xl border border-[#E3DFD6] bg-[#F6F4EF] text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#52504A] mb-1">
                  Home country
                </label>
                <input
                  type="text"
                  value={draftHomeCountry}
                  onChange={(e) => setDraftHomeCountry(e.target.value)}
                  className="w-full min-h-[44px] px-3 rounded-xl border border-[#E3DFD6] bg-[#F6F4EF] text-sm"
                />
              </div>
              <div className="sm:col-span-3">
                <label className="block text-xs font-semibold text-[#52504A] mb-1">
                  Food bio
                </label>
                <input
                  type="text"
                  value={draftBio}
                  onChange={(e) => setDraftBio(e.target.value)}
                  className="w-full min-h-[44px] px-3 rounded-xl border border-[#E3DFD6] bg-[#F6F4EF] text-sm"
                />
              </div>
              <div className="sm:col-span-3 flex justify-end">
                <button
                  type="submit"
                  className="min-h-[44px] px-5 rounded-xl bg-[#141311] text-white text-xs font-semibold inline-flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>Save Profile</span>
                </button>
              </div>
            </form>
          ) : (
            <p className="text-sm text-[#35332F] mt-3 max-w-2xl">{profile.bio}</p>
          )}

          {/* 4-Column Tabular Stats Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-5 border-t border-[#E3DFD6]">
            <div className="p-3.5 rounded-xl bg-[#F0F7F4] border border-[#D7EBE2]">
              <p className="text-xs text-[#45433E]">Dots on World Map</p>
              <p className="text-2xl font-bold font-mono tabular-nums text-[#0E7C58] mt-0.5">
                {visitedReviews.length}
              </p>
            </div>
            <div className="p-3.5 rounded-xl bg-[#F6F4EF] border border-[#E3DFD6]">
              <p className="text-xs text-[#45433E]">Avg Rating Given</p>
              <p className="text-2xl font-bold font-mono tabular-nums text-[#141311] mt-0.5">
                {visitedReviews.length > 0 ? `${avgRating.toFixed(1)} ★` : '—'}
              </p>
            </div>
            <div className="p-3.5 rounded-xl bg-[#F6F4EF] border border-[#E3DFD6]">
              <p className="text-xs text-[#45433E]">Cities / Countries</p>
              <p className="text-2xl font-bold font-mono tabular-nums text-[#141311] mt-0.5">
                {uniqueCitiesCount} / {uniqueCountriesCount}
              </p>
            </div>
            <div className="p-3.5 rounded-xl bg-[#FDF4F3] border border-[#F5D6D2]">
              <p className="text-xs text-[#45433E]">Repeat Favourites</p>
              <p className="text-2xl font-bold font-mono tabular-nums text-[#E84231] mt-0.5">
                {wouldReturnCount}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Taste Likings + Flavour DNA Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 bg-white border border-[#E3DFD6] rounded-2xl p-5 space-y-3">
          <div>
            <h2 className="text-lg font-bold text-[#141311]">Your Food Likings</h2>
            <p className="text-xs text-[#6E6C66]">
              Tap to update what cuisines and dining vibes you want recommended in {destination.cityName} and worldwide.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            {TASTE_LIKING_OPTIONS.map((opt) => {
              const active = tasteLikings.includes(opt.id);
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onToggleLiking(opt.id)}
                  className={`min-h-[38px] px-3.5 rounded-xl text-xs font-semibold border transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-[#141311] border-[#141311] text-white'
                      : 'bg-[#F6F4EF] border-[#E3DFD6] text-[#52504A] hover:border-[#141311]'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="bg-white border border-[#E3DFD6] rounded-2xl p-5 space-y-3">
          <div>
            <h2 className="text-lg font-bold text-[#141311]">Flavour DNA</h2>
            <p className="text-xs text-[#6E6C66]">
              Top signals from your rated places
            </p>
          </div>
          {topTasteSignals.length > 0 ? (
            <div className="space-y-2.5 pt-1">
              {topTasteSignals.map((sig) => (
                <div key={sig.tag} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#141311]">{sig.tag}</span>
                    <span className="font-mono tabular-nums text-[#6E6C66]">
                      {sig.count}x
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-[#EFECE5] overflow-hidden">
                    <div
                      className="h-full bg-[#0E7C58] rounded-full"
                      style={{ width: `${sig.pct}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-[#6E6C66] pt-2 leading-relaxed">
              Rate a couple of spots with taste tags to build your live Flavour DNA chart.
            </p>
          )}
        </div>
      </div>

      {/* Interactive Check Board Embedded Directly on Profile */}
      <InteractiveCheckBoard
        destination={destination}
        visitedReviews={visitedReviews}
        onJumpToPlaceOnMap={onJumpToPlaceOnMap}
        onJumpToCityOnMap={onJumpToCityOnMap}
        onOpenDestinationPicker={onOpenDestinationPicker}
        onEditReview={onEditReview}
        onOpenQuickLog={onOpenQuickLog}
        compactHeader
      />
    </div>
  );
};
