import React, { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import {
  Check,
  CheckCircle2,
  Globe,
  MapPin,
  Plus,
  Star,
  Utensils,
} from 'lucide-react';
import { CHECKBOARD_MILESTONES } from '../data/foodData';
import type { SelectedDestination, VisitedReview } from '../types/food';

interface InteractiveCheckBoardProps {
  destination: SelectedDestination;
  visitedReviews: VisitedReview[];
  onJumpToPlaceOnMap: (review: VisitedReview) => void;
  onJumpToCityOnMap: (cityDest: SelectedDestination) => void;
  onOpenDestinationPicker: () => void;
  onEditReview: (review: VisitedReview) => void;
  onOpenQuickLog: () => void;
  compactHeader?: boolean;
}

interface CitySummary {
  key: string;
  cityName: string;
  countryName: string;
  countryCode: string;
  center: { lat: number; lng: number };
  visits: VisitedReview[];
  avgRating: number;
  isCurrent: boolean;
}

export const InteractiveCheckBoard: React.FC<InteractiveCheckBoardProps> = ({
  destination,
  visitedReviews,
  onJumpToPlaceOnMap,
  onJumpToCityOnMap,
  onOpenDestinationPicker,
  onEditReview,
  onOpenQuickLog,
  compactHeader = false,
}) => {
  const [boardView, setBoardView] = useState<'places' | 'cities' | 'goals'>(
    'places'
  );
  const [cityFilter, setCityFilter] = useState<string>('all');
  const [onlyTopRated, setOnlyTopRated] = useState(false);

  const citySummaries = useMemo<CitySummary[]>(() => {
    const groups: Record<string, CitySummary> = {};

    visitedReviews.forEach((rev) => {
      const key = `${rev.city.toLowerCase()}|${rev.countryCode.toLowerCase()}`;
      if (!groups[key]) {
        groups[key] = {
          key,
          cityName: rev.city,
          countryName: rev.country,
          countryCode: rev.countryCode || 'WD',
          center: rev.location,
          visits: [],
          avgRating: 0,
          isCurrent:
            rev.city.toLowerCase() === destination.cityName.toLowerCase() &&
            rev.countryCode.toLowerCase() === destination.countryCode.toLowerCase(),
        };
      }
      groups[key].visits.push(rev);
    });

    const currentKey = `${destination.cityName.toLowerCase()}|${destination.countryCode.toLowerCase()}`;
    if (!groups[currentKey]) {
      groups[currentKey] = {
        key: currentKey,
        cityName: destination.cityName,
        countryName: destination.countryName,
        countryCode: destination.countryCode,
        center: destination.center,
        visits: [],
        avgRating: 0,
        isCurrent: true,
      };
    } else {
      groups[currentKey].center = destination.center;
    }

    return Object.values(groups)
      .map((g) => ({
        ...g,
        avgRating:
          g.visits.length > 0
            ? g.visits.reduce((acc, r) => acc + r.overallRating, 0) / g.visits.length
            : 0,
      }))
      .sort((a, b) => {
        if (a.isCurrent !== b.isCurrent) return a.isCurrent ? -1 : 1;
        return b.visits.length - a.visits.length;
      });
  }, [visitedReviews, destination]);

  const visitedCityOptions = useMemo(() => {
    const map: Record<string, string> = {};
    visitedReviews.forEach((r) => {
      const key = `${r.city}|${r.countryCode}`;
      map[key] = `${r.city}, ${r.countryCode}`;
    });
    return Object.entries(map).sort((a, b) => a[1].localeCompare(b[1]));
  }, [visitedReviews]);

  const uniqueCountriesCount = useMemo(() => {
    return new Set(
      visitedReviews.map((r) => r.countryCode.toLowerCase()).filter(Boolean)
    ).size;
  }, [visitedReviews]);

  const stampedCitiesCount = useMemo(() => {
    return citySummaries.filter((c) => c.visits.length > 0).length;
  }, [citySummaries]);

  const filteredReviews = useMemo(() => {
    return visitedReviews
      .filter((r) => {
        if (cityFilter !== 'all' && `${r.city}|${r.countryCode}` !== cityFilter) {
          return false;
        }
        if (onlyTopRated && r.overallRating < 4.5) return false;
        return true;
      })
      .sort((a, b) => b.visitedAt.localeCompare(a.visitedAt));
  }, [visitedReviews, cityFilter, onlyTopRated]);

  const unlockedGoalsCount = CHECKBOARD_MILESTONES.filter((m) =>
    m.isUnlocked(visitedReviews)
  ).length;

  return (
    <section className="space-y-5">
      {/* Global Tasting Passport Header & City Stamp Matrix */}
      <div className="bg-[#141311] text-white rounded-2xl p-5 sm:p-6 space-y-5 shadow-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <p className="text-xs font-mono uppercase tracking-wider text-[#34D399]">
              Global Tasting Passport
            </p>
            <h2
              className={`${
                compactHeader ? 'text-2xl' : 'text-2xl sm:text-3xl'
              } font-bold text-white tracking-tight mt-0.5`}
            >
              Interactive Check Board
            </h2>
            <p className="text-sm text-white/70 mt-1 tabular-nums">
              {visitedReviews.length} spots stamped · {stampedCitiesCount} cities ·{' '}
              {uniqueCountriesCount} countries · {unlockedGoalsCount} milestones unlocked
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 p-1 bg-white/10 rounded-xl border border-white/10">
              {[
                { id: 'places' as const, label: `Places (${visitedReviews.length})` },
                { id: 'cities' as const, label: `Cities (${stampedCitiesCount})` },
                {
                  id: 'goals' as const,
                  label: `Goals (${unlockedGoalsCount}/${CHECKBOARD_MILESTONES.length})`,
                },
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setBoardView(tab.id)}
                  className={`min-h-[38px] px-3 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    boardView === tab.id
                      ? 'bg-white text-[#141311]'
                      : 'text-white/75 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={onOpenQuickLog}
              className="min-h-[42px] px-3.5 rounded-xl bg-[#0E7C58] hover:bg-[#0A6245] text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Stamp in {destination.cityName}</span>
            </button>
          </div>
        </div>

        {/* City Stamp Strip */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-2 border-t border-white/10">
          {citySummaries.map((c) => {
            const checkedOff = c.visits.length > 0;
            return (
              <button
                key={c.key}
                type="button"
                onClick={() =>
                  onJumpToCityOnMap({
                    id: `${c.cityName}-${c.countryCode}`,
                    cityName: c.cityName,
                    countryName: c.countryName,
                    countryCode: c.countryCode,
                    formattedAddress: `${c.cityName}, ${c.countryName}`,
                    center: c.center,
                  })
                }
                title={`${c.cityName}, ${c.countryName} (${c.visits.length} visited)`}
                className={`min-h-[54px] min-w-[96px] rounded-xl px-3 py-2 border text-left flex flex-col justify-center gap-0.5 transition-all shrink-0 ${
                  checkedOff
                    ? 'bg-[#0E7C58] border-[#34D399]/50 text-white shadow-sm'
                    : 'bg-white/5 border-white/15 text-white/75 hover:bg-white/10 hover:text-white'
                }`}
              >
                <span className="text-xs font-bold truncate max-w-[130px]">
                  {c.cityName}
                </span>
                <span className="text-[10px] font-mono tabular-nums opacity-85">
                  {c.countryCode} · {checkedOff ? `${c.visits.length} ✓` : 'Active'}
                </span>
              </button>
            );
          })}

          <button
            type="button"
            onClick={onOpenDestinationPicker}
            className="min-h-[54px] px-3.5 rounded-xl border border-dashed border-white/25 text-white/80 hover:text-white hover:border-white/50 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <Globe className="w-3.5 h-3.5 text-[#34D399]" />
            <span>Add City</span>
          </button>
        </div>
      </div>

      {/* Mode 1: Visited Places Check Board */}
      {boardView === 'places' && (
        <div className="space-y-4">
          {visitedReviews.length > 0 && (
            <div className="flex flex-wrap items-center justify-between gap-2 px-1">
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                <button
                  type="button"
                  onClick={() => setCityFilter('all')}
                  className={`min-h-[36px] px-3 rounded-lg text-xs font-semibold border whitespace-nowrap ${
                    cityFilter === 'all'
                      ? 'bg-[#141311] border-[#141311] text-white'
                      : 'bg-white border-[#E3DFD6] text-[#52504A]'
                  }`}
                >
                  All Cities
                </button>
                {visitedCityOptions.map(([key, label]) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setCityFilter(key)}
                    className={`min-h-[36px] px-3 rounded-lg text-xs font-semibold border whitespace-nowrap ${
                      cityFilter === key
                        ? 'bg-[#141311] border-[#141311] text-white'
                        : 'bg-white border-[#E3DFD6] text-[#52504A]'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={() => setOnlyTopRated((v) => !v)}
                className={`min-h-[36px] px-3 rounded-lg text-xs font-semibold border whitespace-nowrap ${
                  onlyTopRated
                    ? 'bg-[#0E7C58] border-[#0E7C58] text-white'
                    : 'bg-white border-[#E3DFD6] text-[#52504A]'
                }`}
              >
                4.5★+ Gems Only
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredReviews.map((review) => (
              <motion.div
                key={review.placeId}
                whileHover={{ y: -2 }}
                transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
                className="bg-white border border-[#C3E0D4] rounded-2xl overflow-hidden flex flex-col justify-between shadow-xs hover:shadow-md hover:border-[#0E7C58] transition-all"
              >
                {review.photoUri ? (
                  <div className="relative h-28 w-full bg-[#1C1B18] overflow-hidden">
                    <img
                      src={review.photoUri}
                      alt={review.placeName}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent" />
                    <span className="absolute top-2.5 left-2.5 px-2.5 py-1 rounded-lg bg-[#0E7C58] text-white text-[11px] font-bold flex items-center gap-1 shadow-sm">
                      <Check className="w-3 h-3 stroke-[3]" />
                      <span>STAMPED</span>
                    </span>
                    <span className="absolute top-2.5 right-2.5 px-2 py-1 rounded-lg bg-black/65 backdrop-blur-xs text-white font-mono tabular-nums text-xs font-bold flex items-center gap-1">
                      <Star className="w-3 h-3 fill-[#34D399] text-[#34D399]" />
                      {review.overallRating.toFixed(1)}
                    </span>
                    <div className="absolute bottom-2.5 left-3 right-3 text-white">
                      <h3 className="text-base font-bold truncate leading-tight">
                        {review.placeName}
                      </h3>
                      <p className="text-[11px] text-white/80 truncate">
                        {review.locality}, {review.city} · {review.countryCode} · {review.primaryTypeLabel}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 pb-0 flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5 min-w-0">
                      <span className="w-8 h-8 rounded-xl bg-[#0E7C58] text-white flex items-center justify-center shrink-0">
                        <Check className="w-4 h-4 stroke-[2.75]" />
                      </span>
                      <div className="min-w-0">
                        <h3 className="text-base font-bold text-[#141311] truncate">
                          {review.placeName}
                        </h3>
                        <p className="text-xs text-[#6E6C66] truncate">
                          {review.locality}, {review.city} · {review.countryCode}
                        </p>
                      </div>
                    </div>
                    <span className="font-mono tabular-nums text-sm font-bold text-[#0E7C58] flex items-center gap-1 shrink-0">
                      <Star className="w-3.5 h-3.5 fill-[#0E7C58] text-[#0E7C58]" />
                      {review.overallRating.toFixed(1)}
                    </span>
                  </div>
                )}

                <div className="p-4 flex-1 flex flex-col justify-between gap-3">
                  <div className="space-y-2">
                    {review.favoriteDish && (
                      <p className="text-xs text-[#35332F]">
                        <span className="font-semibold text-[#141311]">Ordered:</span>{' '}
                        {review.favoriteDish}
                      </p>
                    )}

                    {review.reviewText && (
                      <p className="text-xs text-[#52504A] line-clamp-2 leading-relaxed">
                        “{review.reviewText}”
                      </p>
                    )}

                    <p className="text-[11px] text-[#7A766E] font-mono tabular-nums">
                      {review.visitedAt}
                      {review.tasteTags.length > 0
                        ? ` · ${review.tasteTags.slice(0, 3).join(' · ')}`
                        : ''}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 pt-2 border-t border-[#EFECE5]">
                    <button
                      type="button"
                      onClick={() => onJumpToPlaceOnMap(review)}
                      className="flex-1 min-h-[40px] px-3 rounded-xl bg-[#F6F4EF] hover:bg-[#EAE6DC] text-xs font-semibold text-[#141311] flex items-center justify-center gap-1.5 whitespace-nowrap"
                    >
                      <MapPin className="w-3.5 h-3.5 text-[#0E7C58]" />
                      <span>See Dot on Map</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onEditReview(review)}
                      className="min-h-[40px] px-3.5 rounded-xl border border-[#E3DFD6] hover:bg-[#F6F4EF] text-xs font-semibold text-[#52504A] whitespace-nowrap"
                    >
                      Edit
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}

            {/* Interactive Stamp Trigger Tile */}
            <button
              type="button"
              onClick={onOpenQuickLog}
              className="min-h-[200px] border-2 border-dashed border-[#D3CEC2] hover:border-[#0E7C58] bg-passport-dots bg-[#F6F4EF]/80 hover:bg-[#F0F7F4]/80 rounded-2xl p-6 flex flex-col items-center justify-center text-center gap-2.5 transition-colors group"
            >
              <span className="w-11 h-11 rounded-2xl bg-white border border-[#E3DFD6] group-hover:border-[#0E7C58] group-hover:bg-[#0E7C58] group-hover:text-white flex items-center justify-center text-[#0E7C58] transition-colors shadow-xs">
                <Plus className="w-5 h-5" />
              </span>
              <span className="text-sm font-bold text-[#141311]">
                {visitedReviews.length === 0
                  ? `Stamp your first spot in ${destination.cityName}`
                  : `Stamp another place in ${destination.cityName}`}
              </span>
              <span className="text-xs text-[#6E6C66] max-w-[240px]">
                Search any cafe, bakery, or restaurant in {destination.cityName} to rate it and drop a glowing dot on your world map.
              </span>
            </button>
          </div>
        </div>
      )}

      {/* Mode 2: Worldwide Cities & Countries Board */}
      {boardView === 'cities' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {citySummaries.map((city) => {
            const checkedOff = city.visits.length > 0;
            return (
              <motion.button
                key={city.key}
                whileHover={{ y: -2 }}
                transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
                type="button"
                onClick={() =>
                  onJumpToCityOnMap({
                    id: `${city.cityName}-${city.countryCode}`,
                    cityName: city.cityName,
                    countryName: city.countryName,
                    countryCode: city.countryCode,
                    formattedAddress: `${city.cityName}, ${city.countryName}`,
                    center: city.center,
                  })
                }
                className={`text-left rounded-2xl p-4 border transition-colors flex flex-col justify-between gap-3.5 ${
                  checkedOff
                    ? 'bg-[#F0F7F4] border-[#0E7C58]'
                    : 'bg-white border-[#E3DFD6] hover:border-[#141311]'
                }`}
              >
                <div className="space-y-1.5 w-full">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-mono text-[#7A766E] tabular-nums">
                      {city.countryCode} · {city.countryName}
                    </span>
                    {checkedOff ? (
                      <span className="inline-flex items-center gap-1 text-xs font-bold text-[#0E7C58]">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Stamped</span>
                      </span>
                    ) : (
                      <span className="text-xs font-medium text-[#E84231]">
                        Current City
                      </span>
                    )}
                  </div>
                  <h3 className="text-lg font-bold text-[#141311]">
                    {city.cityName}
                  </h3>
                  <p className="text-xs text-[#52504A]">
                    {checkedOff
                      ? `Average rating: ${city.avgRating.toFixed(1)} ★ across ${city.visits.length} ${city.visits.length === 1 ? 'spot' : 'spots'}`
                      : 'Explore the map and pin your first restaurant or cafe here.'}
                  </p>
                </div>

                <div className="flex items-center justify-between text-xs pt-2 border-t border-black/5">
                  <span className="font-mono tabular-nums font-semibold text-[#141311]">
                    {city.visits.length} {city.visits.length === 1 ? 'dot' : 'dots'}
                  </span>
                  <span className="text-[#E84231] font-semibold">
                    Explore Map →
                  </span>
                </div>
              </motion.button>
            );
          })}

          <button
            type="button"
            onClick={onOpenDestinationPicker}
            className="min-h-[140px] border-2 border-dashed border-[#D3CEC2] hover:border-[#141311] bg-[#F6F4EF]/80 rounded-2xl p-5 flex flex-col items-center justify-center text-center gap-2 transition-colors"
          >
            <Globe className="w-6 h-6 text-[#0E7C58]" />
            <span className="text-sm font-bold text-[#141311]">
              Explore another country or city
            </span>
            <span className="text-xs text-[#6E6C66]">
              Pick any destination worldwide to grow your food atlas.
            </span>
          </button>
        </div>
      )}

      {/* Mode 3: Dining Milestones Checklist */}
      {boardView === 'goals' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {CHECKBOARD_MILESTONES.map((milestone) => {
            const unlocked = milestone.isUnlocked(visitedReviews);
            return (
              <div
                key={milestone.id}
                className={`rounded-2xl p-4 border flex items-center justify-between gap-4 ${
                  unlocked
                    ? 'bg-[#F0F7F4] border-[#0E7C58]'
                    : 'bg-white border-[#E3DFD6]'
                }`}
              >
                <div className="flex items-start gap-3 min-w-0">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      unlocked
                        ? 'bg-[#0E7C58] text-white shadow-xs'
                        : 'bg-[#F3F0EA] text-[#6E6C66]'
                    }`}
                  >
                    {unlocked ? (
                      <Check className="w-5 h-5 stroke-[2.5]" />
                    ) : (
                      <Utensils className="w-4 h-4" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-sm font-bold text-[#141311]">
                      {milestone.title}
                    </h3>
                    <p className="text-xs text-[#52504A] mt-0.5">
                      {milestone.requirement}
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span
                    className={`font-mono tabular-nums text-xs font-bold ${
                      unlocked ? 'text-[#0E7C58]' : 'text-[#6E6C66]'
                    }`}
                  >
                    {milestone.progressText(visitedReviews)}
                  </span>
                  <p className="text-[11px] text-[#6E6C66]">
                    {unlocked ? 'Complete' : 'In progress'}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
};
