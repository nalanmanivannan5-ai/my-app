import React, { useMemo, useState } from 'react';
import { useMapsLibrary } from '@vis.gl/react-google-maps';
import { motion } from 'motion/react';
import {
  ArrowRight,
  Check,
  Globe,
  MapPin,
  Search,
  X,
} from 'lucide-react';
import { WORLD_COUNTRIES } from '../data/countries';
import { useAutocompleteSuggestions } from '../hooks/useAutocompleteSuggestions';
import {
  fetchCityFromPrediction,
  searchCitiesInCountry,
} from '../services/placesService';
import type { CountryOption, SelectedDestination } from '../types/food';

interface DestinationSelectorProps {
  currentDestination: SelectedDestination | null;
  onSelectDestination: (destination: SelectedDestination) => void;
  onClose?: () => void;
  visitedCities?: SelectedDestination[];
}

const CONTINENTS = ['All', 'Americas', 'Europe', 'Asia', 'Oceania', 'Africa'] as const;

export const DestinationSelector: React.FC<DestinationSelectorProps> = ({
  currentDestination,
  onSelectDestination,
  onClose,
  visitedCities = [],
}) => {
  const placesLib = useMapsLibrary('places');

  const initialCountry = useMemo(() => {
    if (!currentDestination) return null;
    return (
      WORLD_COUNTRIES.find(
        (c) =>
          c.code.toUpperCase() === currentDestination.countryCode.toUpperCase()
      ) ?? null
    );
  }, [currentDestination]);

  const [selectedCountry, setSelectedCountry] = useState<CountryOption | null>(
    initialCountry
  );
  const [countrySearch, setCountrySearch] = useState('');
  const [continentFilter, setContinentFilter] = useState<string>('All');
  const [cityQuery, setCityQuery] = useState('');
  const [citySearchResults, setCitySearchResults] = useState<
    SelectedDestination[]
  >([]);
  const [isResolvingCity, setIsResolvingCity] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const {
    suggestions: citySuggestions,
    isLoading: isLoadingSuggestions,
    resetSession,
  } = useAutocompleteSuggestions(cityQuery, {
    mode: 'cities',
    countryCode: selectedCountry?.code,
  });

  const filteredCountries = useMemo(() => {
    const q = countrySearch.trim().toLowerCase();
    return WORLD_COUNTRIES.filter((c) => {
      if (continentFilter !== 'All' && c.continent !== continentFilter) {
        return false;
      }
      if (!q) return true;
      return (
        c.name.toLowerCase().includes(q) || c.code.toLowerCase().includes(q)
      );
    });
  }, [countrySearch, continentFilter]);

  const handleCountryPick = (country: CountryOption) => {
    setSelectedCountry(country);
    setCityQuery('');
    setCitySearchResults([]);
    setErrorMsg(null);
    resetSession();
  };

  const handleCityPredictionPick = async (
    suggestion: google.maps.places.AutocompleteSuggestion
  ) => {
    if (!selectedCountry || !suggestion.placePrediction) return;
    setIsResolvingCity(true);
    setErrorMsg(null);
    try {
      const destination = await fetchCityFromPrediction(
        suggestion.placePrediction,
        selectedCountry
      );
      resetSession();
      if (destination) {
        onSelectDestination(destination);
      } else {
        setErrorMsg('Could not resolve coordinates for that city. Try another.');
      }
    } catch (err) {
      setErrorMsg(
        err instanceof Error
          ? err.message
          : 'Unable to load city details right now.'
      );
    } finally {
      setIsResolvingCity(false);
    }
  };

  const handleCityFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCountry || !cityQuery.trim() || !placesLib) return;
    setIsResolvingCity(true);
    setErrorMsg(null);
    try {
      const results = await searchCitiesInCountry(
        placesLib,
        cityQuery,
        selectedCountry
      );
      if (results.length === 1) {
        resetSession();
        onSelectDestination(results[0]);
      } else if (results.length > 1) {
        setCitySearchResults(results);
      } else {
        setCitySearchResults([]);
        setErrorMsg(
          `No matching city found in ${selectedCountry.name}. Check spelling or pick from suggestions.`
        );
      }
    } catch (err) {
      setErrorMsg(
        err instanceof Error ? err.message : 'City search failed. Try again.'
      );
    } finally {
      setIsResolvingCity(false);
    }
  };

  const isModal = Boolean(onClose && currentDestination);

  return (
    <div
      className={
        isModal
          ? 'fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4'
          : 'min-h-screen bg-[#F6F4EF] bg-passport-dots flex items-center justify-center p-4 sm:p-6'
      }
      role={isModal ? 'dialog' : undefined}
      aria-modal={isModal ? 'true' : undefined}
      aria-labelledby="destination-picker-title"
    >
      <motion.div
        initial={{ opacity: 0, y: 16, scale: 0.99 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
        className={`w-full max-w-4xl bg-white border border-[#E3DFD6] shadow-2xl overflow-hidden flex flex-col ${
          isModal
            ? 'rounded-t-3xl sm:rounded-2xl max-h-[92vh]'
            : 'rounded-2xl max-h-[92vh]'
        }`}
      >
        {/* Dark Editorial Header */}
        <div className="bg-[#141311] text-white px-5 sm:px-7 py-5 flex items-start justify-between gap-4 shrink-0">
          <div className="space-y-1">
            <p className="text-xs font-mono uppercase tracking-wider text-[#34D399]">
              Worldwide Dining Atlas
            </p>
            <h1
              id="destination-picker-title"
              className="text-xl sm:text-2xl font-bold text-white tracking-tight text-balance"
            >
              {isModal
                ? 'Switch Country & City'
                : 'Choose your country and city to start'}
            </h1>
            <p className="text-xs sm:text-sm text-white/70">
              Select any country worldwide, then pick a city to explore restaurants, drop visited dots, and unlock your passport.
            </p>
          </div>
          {isModal && onClose && (
            <button
              type="button"
              onClick={onClose}
              aria-label="Close country and city selector"
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-white/75 hover:bg-white/10 hover:text-white shrink-0"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {visitedCities.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs font-semibold text-[#52504A]">
                Jump back to a stamped city
              </p>
              <div className="flex flex-wrap gap-2">
                {visitedCities.map((city) => (
                  <button
                    key={`${city.cityName}-${city.countryCode}`}
                    type="button"
                    onClick={() => onSelectDestination(city)}
                    className="min-h-[38px] px-3 rounded-xl bg-[#F0F7F4] border border-[#C3E0D4] hover:border-[#0E7C58] text-xs font-semibold text-[#0E7C58] inline-flex items-center gap-1.5 whitespace-nowrap"
                  >
                    <MapPin className="w-3.5 h-3.5" />
                    <span>
                      {city.cityName}, {city.countryCode}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
            {/* Step 1: Country Picker */}
            <div className="lg:col-span-6 space-y-3 border border-[#E3DFD6] rounded-2xl p-4 bg-[#FAF9F6]">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <span className="text-[11px] font-mono font-semibold text-[#0E7C58] uppercase tracking-wider">
                    Step 01
                  </span>
                  <h2 className="text-base font-bold text-[#141311]">
                    Select a Country
                  </h2>
                </div>
                {selectedCountry && (
                  <span className="text-xs font-semibold text-[#0E7C58] inline-flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" />
                    {selectedCountry.name}
                  </span>
                )}
              </div>

              <div className="flex items-center bg-white border border-[#E3DFD6] rounded-xl px-3 focus-within:border-[#141311]">
                <Search className="w-4 h-4 text-[#6E6C66] shrink-0" />
                <input
                  type="text"
                  value={countrySearch}
                  onChange={(e) => setCountrySearch(e.target.value)}
                  placeholder="Filter countries (e.g. Japan, France, Brazil)..."
                  className="w-full min-h-[42px] px-2.5 bg-transparent text-sm text-[#141311] placeholder:text-[#8E8B84] focus:outline-none"
                />
                {countrySearch && (
                  <button
                    type="button"
                    onClick={() => setCountrySearch('')}
                    className="text-xs font-semibold text-[#6E6C66] hover:text-[#141311] px-1"
                  >
                    Clear
                  </button>
                )}
              </div>

              <div className="flex items-center gap-1 overflow-x-auto no-scrollbar pb-0.5">
                {CONTINENTS.map((cont) => (
                  <button
                    key={cont}
                    type="button"
                    onClick={() => setContinentFilter(cont)}
                    className={`min-h-[34px] px-2.5 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap shrink-0 ${
                      continentFilter === cont
                        ? 'bg-[#141311] border-[#141311] text-white'
                        : 'bg-white border-[#E3DFD6] text-[#52504A] hover:border-[#141311]'
                    }`}
                  >
                    {cont}
                  </button>
                ))}
              </div>

              <div className="max-h-64 overflow-y-auto divide-y divide-[#EFECE5] bg-white border border-[#E3DFD6] rounded-xl">
                {filteredCountries.length === 0 ? (
                  <p className="p-4 text-xs text-[#6E6C66] text-center">
                    No countries match “{countrySearch}”.
                  </p>
                ) : (
                  filteredCountries.map((country) => {
                    const active = selectedCountry?.code === country.code;
                    return (
                      <button
                        key={country.code}
                        type="button"
                        onClick={() => handleCountryPick(country)}
                        className={`w-full text-left px-3.5 py-2.5 min-h-[42px] flex items-center justify-between gap-3 transition-colors ${
                          active
                            ? 'bg-[#0E7C58] text-white'
                            : 'hover:bg-[#F6F4EF] text-[#141311]'
                        }`}
                      >
                        <span className="text-sm font-medium truncate">
                          {country.name}
                        </span>
                        <span
                          className={`text-xs font-mono shrink-0 ${
                            active ? 'text-white/90' : 'text-[#7A766E]'
                          }`}
                        >
                          {country.code}
                        </span>
                      </button>
                    );
                  })
                )}
              </div>
            </div>

            {/* Step 2: City Picker */}
            <div className="lg:col-span-6 space-y-3 border border-[#E3DFD6] rounded-2xl p-4 bg-[#FAF9F6]">
              <div>
                <span className="text-[11px] font-mono font-semibold text-[#E84231] uppercase tracking-wider">
                  Step 02
                </span>
                <h2 className="text-base font-bold text-[#141311]">
                  {selectedCountry
                    ? `Choose a City in ${selectedCountry.name}`
                    : 'Choose a City'}
                </h2>
              </div>

              {!selectedCountry ? (
                <div className="min-h-[260px] rounded-xl border border-dashed border-[#D3CEC2] bg-white p-6 flex flex-col items-center justify-center text-center gap-2.5">
                  <Globe className="w-8 h-8 text-[#8E8B84]" />
                  <p className="text-sm font-semibold text-[#141311]">
                    Pick a country first
                  </p>
                  <p className="text-xs text-[#6E6C66] max-w-xs">
                    Select any country on the left, then type your city to load its dining map.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <form onSubmit={handleCityFormSubmit} className="flex gap-2">
                    <div className="flex-1 flex items-center bg-white border border-[#E3DFD6] rounded-xl px-3 focus-within:border-[#141311]">
                      <MapPin className="w-4 h-4 text-[#E84231] shrink-0" />
                      <input
                        type="text"
                        autoFocus
                        value={cityQuery}
                        onChange={(e) => {
                          setCityQuery(e.target.value);
                          setCitySearchResults([]);
                          setErrorMsg(null);
                        }}
                        placeholder={`Type a city in ${selectedCountry.name}...`}
                        className="w-full min-h-[44px] px-2.5 bg-transparent text-sm text-[#141311] placeholder:text-[#8E8B84] focus:outline-none"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={
                        isResolvingCity || !cityQuery.trim() || !placesLib
                      }
                      className="min-h-[44px] px-4 rounded-xl bg-[#E84231] hover:bg-[#D13322] disabled:opacity-50 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
                    >
                      <span>{isResolvingCity ? 'Loading...' : 'Explore'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </form>

                  {errorMsg && (
                    <p className="text-xs text-[#E84231] font-medium">
                      {errorMsg}
                    </p>
                  )}

                  {(isLoadingSuggestions || isResolvingCity) && (
                    <p className="text-xs text-[#6E6C66]">
                      {isResolvingCity
                        ? `Loading ${selectedCountry.name} city map...`
                        : `Searching cities in ${selectedCountry.name}...`}
                    </p>
                  )}

                  {citySuggestions.length > 0 && (
                    <div className="space-y-1.5">
                      <p className="text-xs font-semibold text-[#6E6C66]">
                        Matching cities in {selectedCountry.name}
                      </p>
                      <div className="divide-y divide-[#EFECE5] bg-white border border-[#E3DFD6] rounded-xl overflow-hidden max-h-60 overflow-y-auto">
                        {citySuggestions.map((s, idx) => (
                          <button
                            key={idx}
                            type="button"
                            disabled={isResolvingCity}
                            onClick={() => void handleCityPredictionPick(s)}
                            className="w-full text-left px-3.5 py-3 hover:bg-[#F0F7F4] flex items-center justify-between gap-3 min-h-[46px] transition-colors"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <MapPin className="w-4 h-4 text-[#0E7C58] shrink-0" />
                              <span className="text-sm font-medium text-[#141311] truncate">
                                {s.placePrediction?.text.text}
                              </span>
                            </div>
                            <span className="text-xs font-semibold text-[#0E7C58] shrink-0">
                              Select →
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {citySearchResults.length > 0 && (
                    <div className="space-y-1.5">
                      <p className="text-xs font-semibold text-[#6E6C66]">
                        Choose exact city match
                      </p>
                      <div className="divide-y divide-[#EFECE5] bg-white border border-[#E3DFD6] rounded-xl overflow-hidden max-h-60 overflow-y-auto">
                        {citySearchResults.map((dest) => (
                          <button
                            key={dest.id}
                            type="button"
                            onClick={() => onSelectDestination(dest)}
                            className="w-full text-left px-3.5 py-3 hover:bg-[#F0F7F4] flex items-center justify-between gap-3 min-h-[46px]"
                          >
                            <div className="min-w-0">
                              <p className="text-sm font-semibold text-[#141311] truncate">
                                {dest.cityName}
                              </p>
                              <p className="text-xs text-[#6E6C66] truncate">
                                {dest.formattedAddress}
                              </p>
                            </div>
                            <span className="text-xs font-semibold text-[#0E7C58] shrink-0">
                              Open Map →
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {citySuggestions.length === 0 &&
                    citySearchResults.length === 0 &&
                    !isLoadingSuggestions &&
                    !isResolvingCity && (
                      <div className="rounded-xl bg-white border border-[#E3DFD6] p-4 text-xs text-[#52504A] space-y-1">
                        <p className="font-semibold text-[#141311]">
                          Country set to {selectedCountry.name} ({selectedCountry.code})
                        </p>
                        <p className="leading-relaxed">
                          Start typing any city, town, or dining hub in {selectedCountry.name} above and pick it from the live suggestions—or press Explore.
                        </p>
                      </div>
                    )}
                </div>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
