import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Check, Star, X } from 'lucide-react';
import { REVIEW_TASTE_TAGS } from '../data/foodData';
import type { FoodPlace, ReturnIntent, VisitedReview } from '../types/food';

interface RatingModalProps {
  place: FoodPlace;
  existingReview?: VisitedReview;
  onClose: () => void;
  onSave: (review: VisitedReview) => void;
}

const RATING_STEPS = [1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5];

export const RatingModal: React.FC<RatingModalProps> = ({
  place,
  existingReview,
  onClose,
  onSave,
}) => {
  const [overallRating, setOverallRating] = useState<number>(
    existingReview?.overallRating ?? 4.5
  );
  const [foodRating, setFoodRating] = useState<number>(
    existingReview?.foodRating ?? 5
  );
  const [vibeRating, setVibeRating] = useState<number>(
    existingReview?.vibeRating ?? 4
  );
  const [valueRating, setValueRating] = useState<number>(
    existingReview?.valueRating ?? 4
  );
  const [wouldReturn, setWouldReturn] = useState<ReturnIntent>(
    existingReview?.wouldReturn ?? 'yes'
  );
  const [favoriteDish, setFavoriteDish] = useState<string>(
    existingReview?.favoriteDish ?? ''
  );
  const [reviewText, setReviewText] = useState<string>(
    existingReview?.reviewText ?? ''
  );
  const [tasteTags, setTasteTags] = useState<string[]>(
    existingReview?.tasteTags ?? []
  );
  const [visitedAt, setVisitedAt] = useState<string>(
    existingReview?.visitedAt ?? new Date().toISOString().slice(0, 10)
  );

  const toggleTag = (tag: string) => {
    setTasteTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      placeId: place.id,
      placeName: place.displayName,
      formattedAddress: place.formattedAddress,
      locality: place.locality,
      city: place.city,
      country: place.country,
      countryCode: place.countryCode,
      location: place.location,
      primaryTypeLabel: place.primaryTypeLabel,
      googleMapsURI: place.googleMapsURI,
      photoUri: place.photoUri,
      photoAttributions: place.photoAttributions,
      overallRating,
      foodRating,
      vibeRating,
      valueRating,
      wouldReturn,
      favoriteDish: favoriteDish.trim(),
      reviewText: reviewText.trim(),
      tasteTags,
      visitedAt,
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.16 }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="rate-modal-title"
    >
      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
        className="w-full sm:max-w-lg bg-white rounded-t-3xl sm:rounded-2xl shadow-2xl border border-[#E3DFD6] max-h-[92vh] flex flex-col overflow-hidden"
      >
        <div className="sm:hidden pt-2.5 pb-1 flex justify-center">
          <div className="w-10 h-1.5 rounded-full bg-[#D8D4CC]" />
        </div>

        {/* Dark Editorial Header */}
        <div className="bg-[#141311] text-white flex items-start justify-between gap-4 px-5 py-4">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-[#34D399] tracking-tight">
              {existingReview ? 'Update your visited dot' : 'Check in & drop a dot'}
            </p>
            <h2
              id="rate-modal-title"
              className="text-xl font-bold text-white truncate mt-0.5"
            >
              {place.displayName}
            </h2>
            <p className="text-xs text-white/70 truncate mt-0.5">
              {place.locality}, {place.city} · {place.primaryTypeLabel}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close rating modal"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-white/75 hover:bg-white/10 hover:text-white transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="overflow-y-auto px-5 py-4 space-y-5">
          {/* Overall Score */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-semibold text-[#141311]">
                Overall rating
              </label>
              <span className="font-mono tabular-nums text-base font-bold text-[#0E7C58] flex items-center gap-1">
                <Star className="w-4 h-4 fill-[#0E7C58] text-[#0E7C58]" />
                {overallRating.toFixed(1)} / 5.0
              </span>
            </div>
            <div className="grid grid-cols-9 gap-1 bg-[#F3F0EA] p-1 rounded-xl">
              {RATING_STEPS.map((score) => {
                const active = overallRating === score;
                return (
                  <button
                    key={score}
                    type="button"
                    onClick={() => setOverallRating(score)}
                    className={`min-h-[40px] rounded-lg font-mono tabular-nums text-xs font-semibold transition-colors ${
                      active
                        ? 'bg-[#0E7C58] text-white shadow-xs'
                        : 'text-[#52504A] hover:bg-white/90 hover:text-[#141311]'
                    }`}
                  >
                    {score}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Sub-scores */}
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'Food', value: foodRating, setter: setFoodRating },
              { label: 'Vibe', value: vibeRating, setter: setVibeRating },
              { label: 'Value', value: valueRating, setter: setValueRating },
            ].map((item) => (
              <div
                key={item.label}
                className="bg-[#F6F4EF] border border-[#E3DFD6] rounded-xl p-2.5"
              >
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-medium text-[#52504A]">{item.label}</span>
                  <span className="font-mono tabular-nums font-semibold text-[#141311]">
                    {item.value}/5
                  </span>
                </div>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => item.setter(n)}
                      aria-label={`${item.label} ${n} out of 5`}
                      className={`flex-1 h-7 rounded-md text-xs font-mono transition-colors ${
                        n <= item.value
                          ? 'bg-[#141311] text-white'
                          : 'bg-white border border-[#E3DFD6] text-[#6E6C66]'
                      }`}
                    >
                      {n}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Would Return */}
          <div>
            <label className="block text-sm font-semibold text-[#141311] mb-2">
              Would you go back?
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'yes' as const, label: 'Yes, obsessed' },
                { id: 'maybe' as const, label: 'Maybe' },
                { id: 'no' as const, label: 'One & done' },
              ].map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setWouldReturn(opt.id)}
                  className={`min-h-[44px] px-3 rounded-xl text-xs font-semibold border transition-colors whitespace-nowrap ${
                    wouldReturn === opt.id
                      ? 'bg-[#0E7C58]/10 border-[#0E7C58] text-[#0E7C58]'
                      : 'bg-white border-[#E3DFD6] text-[#52504A] hover:border-[#C9C4BA]'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Favorite Dish & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label
                htmlFor="fav-dish"
                className="block text-xs font-semibold text-[#52504A] mb-1.5"
              >
                Standout dish or order
              </label>
              <input
                id="fav-dish"
                type="text"
                value={favoriteDish}
                onChange={(e) => setFavoriteDish(e.target.value)}
                placeholder="e.g. Spicy pork ramen, croissant, espresso"
                className="w-full min-h-[44px] px-3.5 rounded-xl border border-[#E3DFD6] bg-[#F6F4EF] text-sm text-[#141311] placeholder:text-[#8E8B84] focus:outline-none focus:border-[#141311] focus:bg-white"
              />
            </div>
            <div>
              <label
                htmlFor="visit-date"
                className="block text-xs font-semibold text-[#52504A] mb-1.5"
              >
                Date visited
              </label>
              <input
                id="visit-date"
                type="date"
                value={visitedAt}
                onChange={(e) => setVisitedAt(e.target.value)}
                className="w-full min-h-[44px] px-3 rounded-xl border border-[#E3DFD6] bg-[#F6F4EF] text-sm text-[#141311] focus:outline-none focus:border-[#141311] focus:bg-white"
              />
            </div>
          </div>

          {/* Taste Likings Tags */}
          <div>
            <label className="block text-sm font-semibold text-[#141311] mb-1">
              What did you love here?
            </label>
            <p className="text-xs text-[#6E6C66] mb-2.5">
              These shape your personalized recommendations in every city.
            </p>
            <div className="flex flex-wrap gap-1.5">
              {REVIEW_TASTE_TAGS.map((tag) => {
                const selected = tasteTags.includes(tag);
                return (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => toggleTag(tag)}
                    className={`min-h-[36px] px-3 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap ${
                      selected
                        ? 'bg-[#141311] border-[#141311] text-white'
                        : 'bg-[#F6F4EF] border-[#E3DFD6] text-[#52504A] hover:border-[#C9C4BA]'
                    }`}
                  >
                    {tag}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Short Note */}
          <div>
            <label
              htmlFor="review-note"
              className="block text-xs font-semibold text-[#52504A] mb-1.5"
            >
              Tasting notes
            </label>
            <textarea
              id="review-note"
              rows={3}
              value={reviewText}
              onChange={(e) => setReviewText(e.target.value)}
              placeholder="Quick thoughts on seating, wait time, or what to order next visit..."
              className="w-full p-3.5 rounded-xl border border-[#E3DFD6] bg-[#F6F4EF] text-sm text-[#141311] placeholder:text-[#8E8B84] focus:outline-none focus:border-[#141311] focus:bg-white resize-none"
            />
          </div>

          {/* Submit Footer */}
          <div className="pt-2 pb-safe flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[48px] px-5 rounded-xl border border-[#E3DFD6] text-sm font-semibold text-[#52504A] hover:bg-[#F3F0EA] transition-colors whitespace-nowrap"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 min-h-[48px] px-5 rounded-xl bg-[#0E7C58] hover:bg-[#0A6245] text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors active:scale-[0.99] shadow-sm whitespace-nowrap"
            >
              <Check className="w-4 h-4" />
              {existingReview ? 'Save Updated Review' : 'Pin Visited Dot & Save'}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};
