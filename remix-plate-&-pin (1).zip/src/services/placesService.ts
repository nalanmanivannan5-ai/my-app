import type {
  CountryOption,
  FoodPlace,
  LatLngPoint,
  PlaceAuthorAttribution,
  PlaceReviewSnippet,
  SelectedDestination,
  ViewportBounds,
} from '../types/food';

export const ATTRIBUTION_ID = 'gmp_mcp_codeassist_v1_aistudio';

const BASE_PLACE_FIELDS = [
  'id',
  'displayName',
  'formattedAddress',
  'addressComponents',
  'location',
  'primaryType',
  'primaryTypeDisplayName',
  'types',
  'rating',
  'userRatingCount',
  'priceLevel',
  'photos',
  'googleMapsURI',
];

const CITY_PLACE_FIELDS = [
  'id',
  'displayName',
  'formattedAddress',
  'addressComponents',
  'location',
  'viewport',
];

function checkQuotaError(error: unknown) {
  const msg = error instanceof Error ? error.message : String(error);
  if (
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('OVER_QUERY_LIMIT') ||
    msg.includes('QuotaExceededError') ||
    msg.includes('OverQuotaMapError') ||
    msg.includes('429')
  ) {
    window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
  }
}

function getLatLng(loc: unknown): LatLngPoint | null {
  if (!loc || typeof loc !== 'object') return null;
  const candidate = loc as {
    lat?: number | (() => number);
    lng?: number | (() => number);
  };
  const lat =
    typeof candidate.lat === 'function' ? candidate.lat() : candidate.lat;
  const lng =
    typeof candidate.lng === 'function' ? candidate.lng() : candidate.lng;
  if (typeof lat !== 'number' || typeof lng !== 'number') return null;
  return { lat, lng };
}

function extractViewportBounds(viewport: unknown): ViewportBounds | undefined {
  if (!viewport || typeof viewport !== 'object') return undefined;
  const vp = viewport as {
    toJSON?: () => { south: number; west: number; north: number; east: number };
    getSouthWest?: () => { lat: () => number; lng: () => number };
    getNorthEast?: () => { lat: () => number; lng: () => number };
  };
  if (typeof vp.toJSON === 'function') {
    const json = vp.toJSON();
    if (
      typeof json?.south === 'number' &&
      typeof json?.west === 'number' &&
      typeof json?.north === 'number' &&
      typeof json?.east === 'number'
    ) {
      return json;
    }
  }
  if (typeof vp.getSouthWest === 'function' && typeof vp.getNorthEast === 'function') {
    const sw = vp.getSouthWest();
    const ne = vp.getNorthEast();
    return {
      south: sw.lat(),
      west: sw.lng(),
      north: ne.lat(),
      east: ne.lng(),
    };
  }
  return undefined;
}

function extractAddressMeta(
  place: google.maps.places.Place,
  fallback?: { city?: string; country?: string; countryCode?: string }
): {
  locality: string;
  city: string;
  country: string;
  countryCode: string;
} {
  const components = place.addressComponents ?? [];
  const findComp = (...types: string[]) =>
    components.find((c) => types.some((t) => c.types?.includes(t)));

  const neighborhood = findComp(
    'neighborhood',
    'sublocality_level_1',
    'sublocality',
    'ward'
  );
  const localityComp = findComp(
    'locality',
    'postal_town',
    'administrative_area_level_2',
    'administrative_area_level_1'
  );
  const countryComp = findComp('country');

  const city =
    localityComp?.longText ||
    fallback?.city ||
    place.displayName ||
    'Local City';
  const country = countryComp?.longText || fallback?.country || 'Worldwide';
  const countryCode = (
    countryComp?.shortText ||
    fallback?.countryCode ||
    ''
  ).toUpperCase();

  let locality = neighborhood?.longText || '';
  if (!locality) {
    const parts = (place.formattedAddress ?? '')
      .split(',')
      .map((p) => p.trim())
      .filter(Boolean);
    if (parts.length >= 2) {
      locality = parts[1].replace(/\d{3,}/g, '').trim();
    }
  }
  if (!locality) {
    locality = city;
  }

  return { locality, city, country, countryCode };
}

export function formatPriceLevel(priceLevel?: unknown): string | undefined {
  if (!priceLevel) return undefined;
  const val = String(priceLevel).toUpperCase();
  if (val.includes('INEXPENSIVE') || val === '1') return '$';
  if (val.includes('MODERATE') || val === '2') return '$$';
  if (val.includes('VERY_EXPENSIVE') || val === '4') return '$$$$';
  if (val.includes('EXPENSIVE') || val === '3') return '$$$';
  if (val.includes('FREE') || val === '0') return 'Free';
  return undefined;
}

export function formatPrimaryTypeLabel(place: google.maps.places.Place): string {
  if (place.primaryTypeDisplayName) {
    return place.primaryTypeDisplayName;
  }
  if (place.primaryType) {
    return place.primaryType
      .split('_')
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(' ');
  }
  return 'Food Spot';
}

export function normalizeGooglePlace(
  place: google.maps.places.Place,
  fallback?: { city?: string; country?: string; countryCode?: string }
): FoodPlace | null {
  if (!place.id || !place.location) return null;

  const location = getLatLng(place.location);
  if (!location) return null;

  const formattedAddress = place.formattedAddress ?? '';
  const meta = extractAddressMeta(place, fallback);

  let photoUri: string | undefined;
  let photoAttributions: PlaceAuthorAttribution[] | undefined;
  if (place.photos && place.photos.length > 0) {
    try {
      photoUri = place.photos[0].getURI({ maxWidth: 680, maxHeight: 480 });
      photoAttributions = place.photos[0].authorAttributions?.map((a) => ({
        displayName: a.displayName,
        uri: a.uri,
      }));
    } catch {
      photoUri = undefined;
    }
  }

  const attributions = place.attributions?.map((a) => ({
    provider: a.provider ?? 'Google Maps',
    providerURI: a.providerURI,
  }));

  const reviews: PlaceReviewSnippet[] | undefined = place.reviews
    ?.slice(0, 3)
    .map((r) => ({
      rating: r.rating,
      text: r.text,
      relativePublishTimeDescription: r.relativePublishTimeDescription,
      authorName: r.authorAttribution?.displayName,
    }));

  return {
    id: place.id,
    displayName: place.displayName ?? 'Local Eatery',
    formattedAddress,
    locality: meta.locality,
    city: meta.city,
    country: meta.country,
    countryCode: meta.countryCode,
    location,
    primaryType: place.primaryType ?? 'restaurant',
    primaryTypeLabel: formatPrimaryTypeLabel(place),
    types: place.types ?? [],
    rating: place.rating ?? undefined,
    userRatingCount: place.userRatingCount ?? undefined,
    priceLevel: formatPriceLevel(place.priceLevel),
    photoUri,
    photoAttributions,
    googleMapsURI: place.googleMapsURI ?? undefined,
    attributions,
    editorialSummary: place.editorialSummary ?? undefined,
    websiteURI: place.websiteURI ?? undefined,
    reviews,
  };
}

function normalizeDestinationFromPlace(
  place: google.maps.places.Place,
  fallbackCountry: CountryOption
): SelectedDestination | null {
  if (!place.id || !place.location) return null;
  const center = getLatLng(place.location);
  if (!center) return null;

  const meta = extractAddressMeta(place, {
    city: place.displayName ?? '',
    country: fallbackCountry.name,
    countryCode: fallbackCountry.code,
  });

  const cityName = place.displayName || meta.city;

  return {
    id: place.id,
    cityName,
    countryName: meta.country || fallbackCountry.name,
    countryCode: (meta.countryCode || fallbackCountry.code).toUpperCase(),
    formattedAddress:
      place.formattedAddress || `${cityName}, ${fallbackCountry.name}`,
    center,
    viewport: extractViewportBounds(place.viewport),
  };
}

export async function fetchCityFromPrediction(
  prediction: google.maps.places.PlacePrediction,
  fallbackCountry: CountryOption
): Promise<SelectedDestination | null> {
  try {
    const place = prediction.toPlace();
    await place.fetchFields({
      fields: CITY_PLACE_FIELDS,
    });
    return normalizeDestinationFromPlace(place, fallbackCountry);
  } catch (error) {
    checkQuotaError(error);
    throw error;
  }
}

export async function searchCitiesInCountry(
  placesLib: google.maps.PlacesLibrary,
  cityQuery: string,
  country: CountryOption
): Promise<SelectedDestination[]> {
  try {
    const { Place } = placesLib;
    const trimmed = cityQuery.trim();
    if (!trimmed) return [];

    const request: google.maps.places.SearchByTextRequest = {
      textQuery: `${trimmed}, ${country.name}`,
      fields: CITY_PLACE_FIELDS,
      maxResultCount: 6,
      language: 'en',
      region: country.code.toLowerCase(),
      internalUsageAttributionIds: [ATTRIBUTION_ID],
    };

    const { places } = await Place.searchByText(request);
    return places
      .map((p) => normalizeDestinationFromPlace(p, country))
      .filter((d): d is SelectedDestination => d !== null);
  } catch (error) {
    checkQuotaError(error);
    throw error;
  }
}

export async function searchNearbyFood(
  placesLib: google.maps.PlacesLibrary,
  options: {
    center: LatLngPoint;
    radiusMeters?: number;
    includedPrimaryTypes?: string[];
    maxResultCount?: number;
    regionCode?: string;
    destinationContext?: { city?: string; country?: string; countryCode?: string };
  }
): Promise<FoodPlace[]> {
  try {
    const { Place, SearchNearbyRankPreference } = placesLib;
    const radius = Math.min(Math.max(options.radiusMeters ?? 2500, 200), 50000);

    const request: google.maps.places.SearchNearbyRequest = {
      fields: BASE_PLACE_FIELDS,
      locationRestriction: {
        center: options.center,
        radius,
      },
      includedPrimaryTypes:
        options.includedPrimaryTypes && options.includedPrimaryTypes.length > 0
          ? options.includedPrimaryTypes
          : ['restaurant', 'cafe', 'bakery'],
      maxResultCount: options.maxResultCount ?? 18,
      rankPreference: SearchNearbyRankPreference.POPULARITY,
      language: 'en',
      region: options.regionCode ? options.regionCode.toLowerCase() : undefined,
      internalUsageAttributionIds: [ATTRIBUTION_ID],
    };

    const { places } = await Place.searchNearby(request);
    return places
      .map((p) => normalizeGooglePlace(p, options.destinationContext))
      .filter((p): p is FoodPlace => p !== null);
  } catch (error) {
    checkQuotaError(error);
    throw error;
  }
}

export async function searchFoodByText(
  placesLib: google.maps.PlacesLibrary,
  options: {
    textQuery: string;
    center: LatLngPoint;
    radiusMeters?: number;
    maxResultCount?: number;
    regionCode?: string;
    destinationContext?: { city?: string; country?: string; countryCode?: string };
  }
): Promise<FoodPlace[]> {
  try {
    const { Place } = placesLib;
    const request: google.maps.places.SearchByTextRequest = {
      textQuery: options.textQuery,
      fields: BASE_PLACE_FIELDS,
      locationBias: {
        center: options.center,
        radius: options.radiusMeters ?? 15000,
      },
      maxResultCount: options.maxResultCount ?? 15,
      language: 'en',
      region: options.regionCode ? options.regionCode.toLowerCase() : undefined,
      internalUsageAttributionIds: [ATTRIBUTION_ID],
    };

    const { places } = await Place.searchByText(request);
    return places
      .map((p) => normalizeGooglePlace(p, options.destinationContext))
      .filter((p): p is FoodPlace => p !== null);
  } catch (error) {
    checkQuotaError(error);
    throw error;
  }
}

export async function fetchFoodPlaceDetails(
  placesLib: google.maps.PlacesLibrary,
  placeId: string,
  destinationContext?: { city?: string; country?: string; countryCode?: string }
): Promise<FoodPlace | null> {
  try {
    const { Place } = placesLib;
    const place = new Place({
      id: placeId,
      requestedLanguage: 'en',
      requestedRegion: destinationContext?.countryCode?.toLowerCase(),
    });

    await place.fetchFields({
      fields: [
        ...BASE_PLACE_FIELDS,
        'editorialSummary',
        'websiteURI',
        'reviews',
      ],
    });

    return normalizeGooglePlace(place, destinationContext);
  } catch (error) {
    checkQuotaError(error);
    throw error;
  }
}
